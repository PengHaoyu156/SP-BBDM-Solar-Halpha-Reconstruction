#frozen
#python train_nafnet_roi_refiner_frozen.py \
#  --train_a_dir /home/a/ref-solarimage/train/A \
#  --train_b_dir /home/a/ref-solarimage/train/B \
#  --train_sp_dir /home/a/ref-solarimage/train/SP \
#  --val_a_dir /home/a/ref-solarimage/val/A \
#  --val_b_dir /home/a/ref-solarimage/val/B \
#  --val_sp_dir /home/a/ref-solarimage/val/SP \
#  --match_mode sorted \
#  --out_dir runs/ref_frozen_mask1 \
#  --patch_size 96 \
#  --full_image_size 256 \
#  --patches_per_image 4 \
#  --roi_source a_sp_union \
#  --roi_bright_quantile 0.95 \
#  --roi_grad_quantile 0.97 \
#  --roi_contrast_quantile 0.97 \
#  --roi_dilate_kernel 5 \
#  --roi_center_disk_margin 0.55 \
#  --mask_smooth_times 1 \
#  --width 32 \
#  --middle_blk_num 4 \
#  --enc_blks 2,2,4 \
#  --dec_blks 2,2,2 \
#  --epochs 100 \
#  --max_steps 50000 \
#  --batch_size 8 \
#  --lr 2e-4 \
#  --device cuda:0 \
#  --lambda_res 1.0 \
#  --lambda_refined 1.0 \
#  --lambda_grad 0.05 \
#  --lambda_sobel 0.05 \
#  --lambda_lpips 0.01 \
#  --lambda_res_mag 0.01 \
#  --lpips_net alex \
#  --mask_boost 3.0 \
#  --log_interval 10 \
#  --metric_step_interval 1000 \
#  --preview_step_interval 500 \
#  --save_step_interval 1000 \
#  --save_interval 5 \
#  --amp


#测试
#python test_nafnet_roi_refiner_frozen.py \
#  --test_a /home/a/ref-solarimage/test/A \
#  --test_b /home/a/ref-solarimage/test/B \
#  --test_sp /home/a/ref-solarimage/test/SP \
#  --checkpoint runs/ref_frozen_mask1/checkpoints/step_00070000.pth \
#  --out_dir runs/ref_frozen_mask1/test_step80000 \
#  --match_mode sorted \
#  --clear_out_dir \
#  --patch_size 96 \
#  --num_rois_per_image 4 \
#  --roi_source a_sp_union \
#  --roi_bright_quantile 0.95 \
#  --roi_grad_quantile 0.97 \
#  --roi_contrast_quantile 0.97 \
#  --roi_dilate_kernel 5 \
#  --roi_center_disk_margin 0.55 \
#  --mask_smooth_times 1 \
#  --save_full_images \
#  --save_roi_patches \
#  --device cuda:0


#ssim psnr  lpips
#python3 print_psnr_ssim_lpips_mean_std.py \
#  --pred runs/ref_frozen_mask1/test_step80000/full_refined \
#  --gt runs/ref_frozen_mask1/test_step80000/full_gt \
#  --device cuda \
#  --csv spbbdm_per_image_metrics.csv

