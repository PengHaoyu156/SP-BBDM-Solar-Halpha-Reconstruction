#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Directly print PSNR/SSIM for paired images (folder or single file).
- If given two folders, it matches by filename and prints mean/median to stdout.
- If given two files, it prints the metrics for that single pair.
Usage:
  python3 tools/print_psnr_ssim.py --pred <path> --gt <path> [--per_image] [--border 0]
"""

import os, cv2, math, argparse, numpy as np
from typing import Tuple, List

ALLOWED = ('.png','.jpg','.jpeg','.bmp','.tif','.tiff')

def is_file(p): return os.path.isfile(p)
def is_dir(p):  return os.path.isdir(p)

def center_crop_to_common(a: np.ndarray, b: np.ndarray) -> Tuple[np.ndarray,np.ndarray]:
    h = min(a.shape[0], b.shape[0]); w = min(a.shape[1], b.shape[1])
    def crop(x):
        dh = (x.shape[0]-h)//2; dw = (x.shape[1]-w)//2
        return x[dh:dh+h, dw:dw+w]
    return crop(a), crop(b)

def to_u8(x: np.ndarray)->np.ndarray:
    return x if x.dtype==np.uint8 else np.clip(x,0,255).astype(np.uint8)

def psnr(x: np.ndarray, y: np.ndarray, border=0)->float:
    if x.shape!=y.shape: raise ValueError("PSNR: shape mismatch after cropping.")
    h,w = x.shape[:2]
    if border>0:
        x = x[border:h-border, border:w-border]
        y = y[border:h-border, border:w-border]
    x = x.astype(np.float64); y = y.astype(np.float64)
    mse = np.mean((x-y)**2)
    if mse<=1e-12: return float('inf')
    return 20.0*math.log10(255.0/math.sqrt(mse))

def ssim_gray(x: np.ndarray, y: np.ndarray)->float:
    C1=(0.01*255)**2; C2=(0.03*255)**2
    x=x.astype(np.float64); y=y.astype(np.float64)
    k=cv2.getGaussianKernel(11,1.5); win=np.outer(k,k.T)
    mux=cv2.filter2D(x,-1,win)[5:-5,5:-5]; muy=cv2.filter2D(y,-1,win)[5:-5,5:-5]
    mux2=mux*mux; muy2=muy*muy; muxy=mux*muy
    sigx2=cv2.filter2D(x*x,-1,win)[5:-5,5:-5]-mux2
    sigy2=cv2.filter2D(y*y,-1,win)[5:-5,5:-5]-muy2
    sigxy=cv2.filter2D(x*y,-1,win)[5:-5,5:-5]-muxy
    s=((2*muxy+C1)*(2*sigxy+C2))/((mux2+muy2+C1)*(sigx2+sigy2+C2))
    return float(s.mean())

def ssim(x: np.ndarray, y: np.ndarray, border=0)->float:
    if x.shape!=y.shape: raise ValueError("SSIM: shape mismatch after cropping.")
    h,w=x.shape[:2]
    if border>0:
        x=x[border:h-border, border:w-border]
        y=y[border:h-border, border:w-border]
    if x.ndim==2: return ssim_gray(x,y)
    if x.ndim==3:
        if x.shape[2]==3:
            return float(np.mean([ssim_gray(x[:,:,c],y[:,:,c]) for c in range(3)]))
        if x.shape[2]==1: return ssim_gray(x[:,:,0], y[:,:,0])
        # unexpected channels: fallback to gray
        return ssim_gray(cv2.cvtColor(x, cv2.COLOR_BGR2GRAY),
                         cv2.cvtColor(y, cv2.COLOR_BGR2GRAY))
    raise ValueError("SSIM: wrong ndim.")

def list_imgs(d: str)->List[str]:
    fs=[f for f in os.listdir(d) if os.path.isfile(os.path.join(d,f)) and f.lower().endswith(ALLOWED)]
    fs.sort(); return fs

def eval_pair(p_path: str, g_path: str, border=0)->Tuple[float,float]:
    p=cv2.imread(p_path, cv2.IMREAD_COLOR); g=cv2.imread(g_path, cv2.IMREAD_COLOR)
    if p is None or g is None: raise FileNotFoundError(f"read fail: {p_path} or {g_path}")
    if p.shape!=g.shape: p,g=center_crop_to_common(p,g)
    p=to_u8(p); g=to_u8(g)
    return psnr(p,g,border), ssim(p,g,border)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--pred', required=True)
    ap.add_argument('--gt',   required=True)
    ap.add_argument('--border', type=int, default=0)
    ap.add_argument('--per_image', action='store_true', help='print per-image metrics when evaluating folders')
    args=ap.parse_args()

    # single file vs file
    if is_file(args.pred) and is_file(args.gt):
        PS, SS = eval_pair(args.pred, args.gt, args.border)
        print(f"PSNR: {PS:.3f}")
        print(f"SSIM: {SS:.4f}")
        return

    # folder vs folder
    if not (is_dir(args.pred) and is_dir(args.gt)):
        raise ValueError("Both --pred and --gt must be directories, or both must be files.")

    pred_files=list_imgs(args.pred); gt_set=set(list_imgs(args.gt))
    ps_list=[]; ss_list=[]; matched=0

    for fn in pred_files:
        if fn not in gt_set: continue
        PS, SS = eval_pair(os.path.join(args.pred,fn), os.path.join(args.gt,fn), args.border)
        ps_list.append(PS); ss_list.append(SS); matched+=1
        if args.per_image:
            print(f"{fn}, PSNR={PS:.3f}, SSIM={SS:.4f}")

    if matched==0:
        print("No matched image pairs."); return

    print(f"COUNT: {matched}")
    print(f"PSNR  mean/median: {np.mean(ps_list):.3f} / {np.median(ps_list):.3f}")
    print(f"SSIM  mean/median: {np.mean(ss_list):.4f} / {np.median(ss_list):.4f}")

if __name__=='__main__':
    main()
