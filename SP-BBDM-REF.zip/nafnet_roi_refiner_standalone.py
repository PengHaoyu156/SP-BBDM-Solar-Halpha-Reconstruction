"""
Standalone NAFNet-style ROI residual refiner.

This file is adapted for solar ROI residual refinement without requiring the
full BasicSR / NAFNet repository.

Intended task:
    input  = concat(AIA_patch, SP_BBDM_patch, ROI_mask[, coord_x, coord_y])
             e.g. 7 channels: AIA(3) + SP(3) + mask(1)
             e.g. 9 channels: AIA(3) + SP(3) + mask(1) + coord_x(1) + coord_y(1)
    output = residual_patch, 3 channels
    final  = SP_patch + ROI_mask * residual_patch

Architecture follows the core NAFNet design:
    - LayerNorm2d
    - SimpleGate
    - NAFBlock
    - U-shaped encoder/decoder with skip connections

Reference:
    Chen et al., "Simple Baselines for Image Restoration", 2022.
    Official NAFNet repository: https://github.com/megvii-research/NAFNet
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class LayerNormFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor, eps: float):
        ctx.eps = eps
        _, c, _, _ = x.size()
        mu = x.mean(1, keepdim=True)
        var = (x - mu).pow(2).mean(1, keepdim=True)
        y = (x - mu) / torch.sqrt(var + eps)
        ctx.save_for_backward(y, var, weight)
        y = weight.view(1, c, 1, 1) * y + bias.view(1, c, 1, 1)
        return y

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        eps = ctx.eps
        _, c, _, _ = grad_output.size()
        y, var, weight = ctx.saved_tensors
        g = grad_output * weight.view(1, c, 1, 1)
        mean_g = g.mean(dim=1, keepdim=True)
        mean_gy = (g * y).mean(dim=1, keepdim=True)
        gx = 1.0 / torch.sqrt(var + eps) * (g - y * mean_gy - mean_g)
        grad_weight = (grad_output * y).sum(dim=(0, 2, 3))
        grad_bias = grad_output.sum(dim=(0, 2, 3))
        return gx, grad_weight, grad_bias, None


class LayerNorm2d(nn.Module):
    def __init__(self, channels: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(channels))
        self.bias = nn.Parameter(torch.zeros(channels))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return LayerNormFunction.apply(x, self.weight, self.bias, self.eps)


class SimpleGate(nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x1, x2 = x.chunk(2, dim=1)
        return x1 * x2


class NAFBlock(nn.Module):
    def __init__(self, c: int, dw_expand: int = 2, ffn_expand: int = 2, drop_out_rate: float = 0.0):
        super().__init__()
        dw_channel = c * dw_expand

        self.norm1 = LayerNorm2d(c)
        self.conv1 = nn.Conv2d(c, dw_channel, kernel_size=1, padding=0, stride=1, bias=True)
        self.conv2 = nn.Conv2d(
            dw_channel,
            dw_channel,
            kernel_size=3,
            padding=1,
            stride=1,
            groups=dw_channel,
            bias=True,
        )
        self.sg = SimpleGate()

        # Simplified channel attention.
        self.sca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dw_channel // 2, dw_channel // 2, kernel_size=1, padding=0, stride=1, bias=True),
        )
        self.conv3 = nn.Conv2d(dw_channel // 2, c, kernel_size=1, padding=0, stride=1, bias=True)
        self.dropout1 = nn.Dropout(drop_out_rate) if drop_out_rate > 0 else nn.Identity()

        self.norm2 = LayerNorm2d(c)
        ffn_channel = ffn_expand * c
        self.conv4 = nn.Conv2d(c, ffn_channel, kernel_size=1, padding=0, stride=1, bias=True)
        self.conv5 = nn.Conv2d(ffn_channel // 2, c, kernel_size=1, padding=0, stride=1, bias=True)
        self.dropout2 = nn.Dropout(drop_out_rate) if drop_out_rate > 0 else nn.Identity()

        self.beta = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)
        self.gamma = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)

    def forward(self, inp: torch.Tensor) -> torch.Tensor:
        x = self.norm1(inp)
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.sg(x)
        x = x * self.sca(x)
        x = self.conv3(x)
        x = self.dropout1(x)
        y = inp + x * self.beta

        x = self.norm2(y)
        x = self.conv4(x)
        x = self.sg(x)
        x = self.conv5(x)
        x = self.dropout2(x)
        return y + x * self.gamma


class NAFNetROIRefiner(nn.Module):
    """
    NAFNet-style residual refiner for ROI patches.

    Parameters
    ----------
    in_channels:
        Number of input channels. Recommended:
            7 = AIA(3) + SP(3) + mask(1)
            9 = AIA(3) + SP(3) + mask(1) + coord_x(1) + coord_y(1)
    out_channels:
        Number of output channels. Usually 3 for RGB residual.
    width:
        Base channel width. Start with 32 for 96/128 ROI patches; use 16 if GPU memory is tight.
    enc_blk_nums / dec_blk_nums / middle_blk_num:
        Network depth configuration.
    """

    def __init__(
        self,
        in_channels: int = 7,
        out_channels: int = 3,
        width: int = 32,
        middle_blk_num: int = 4,
        enc_blk_nums: list[int] | tuple[int, ...] = (2, 2, 4),
        dec_blk_nums: list[int] | tuple[int, ...] = (2, 2, 2),
        drop_out_rate: float = 0.0,
        residual_scale: float = 1.0,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.residual_scale = float(residual_scale)

        self.intro = nn.Conv2d(in_channels, width, kernel_size=3, padding=1, stride=1, bias=True)
        self.ending = nn.Conv2d(width, out_channels, kernel_size=3, padding=1, stride=1, bias=True)

        self.encoders = nn.ModuleList()
        self.decoders = nn.ModuleList()
        self.ups = nn.ModuleList()
        self.downs = nn.ModuleList()

        chan = width
        for num in enc_blk_nums:
            self.encoders.append(nn.Sequential(*[NAFBlock(chan, drop_out_rate=drop_out_rate) for _ in range(num)]))
            self.downs.append(nn.Conv2d(chan, chan * 2, kernel_size=2, stride=2))
            chan *= 2

        self.middle_blks = nn.Sequential(*[NAFBlock(chan, drop_out_rate=drop_out_rate) for _ in range(middle_blk_num)])

        for num in dec_blk_nums:
            self.ups.append(
                nn.Sequential(
                    nn.Conv2d(chan, chan * 2, kernel_size=1, bias=False),
                    nn.PixelShuffle(2),
                )
            )
            chan //= 2
            self.decoders.append(nn.Sequential(*[NAFBlock(chan, drop_out_rate=drop_out_rate) for _ in range(num)]))

        self.padder_size = 2 ** len(self.encoders)

    def check_image_size(self, x: torch.Tensor) -> torch.Tensor:
        _, _, h, w = x.size()
        mod_pad_h = (self.padder_size - h % self.padder_size) % self.padder_size
        mod_pad_w = (self.padder_size - w % self.padder_size) % self.padder_size
        if mod_pad_h != 0 or mod_pad_w != 0:
            x = F.pad(x, (0, mod_pad_w, 0, mod_pad_h), mode="reflect")
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        x = self.check_image_size(x)

        feat = self.intro(x)
        encs = []

        for encoder, down in zip(self.encoders, self.downs):
            feat = encoder(feat)
            encs.append(feat)
            feat = down(feat)

        feat = self.middle_blks(feat)

        for decoder, up, enc_skip in zip(self.decoders, self.ups, encs[::-1]):
            feat = up(feat)
            # In case of odd padding, align spatial size before skip addition.
            if feat.shape[-2:] != enc_skip.shape[-2:]:
                feat = feat[:, :, : enc_skip.shape[-2], : enc_skip.shape[-1]]
            feat = feat + enc_skip
            feat = decoder(feat)

        out = self.ending(feat)
        out = out[:, :, :h, :w]
        return out * self.residual_scale


def build_nafnet_roi_refiner(
    in_channels: int = 7,
    out_channels: int = 3,
    width: int = 32,
    middle_blk_num: int = 4,
    enc_blk_nums: tuple[int, ...] = (2, 2, 4),
    dec_blk_nums: tuple[int, ...] = (2, 2, 2),
) -> NAFNetROIRefiner:
    return NAFNetROIRefiner(
        in_channels=in_channels,
        out_channels=out_channels,
        width=width,
        middle_blk_num=middle_blk_num,
        enc_blk_nums=enc_blk_nums,
        dec_blk_nums=dec_blk_nums,
    )


if __name__ == "__main__":
    model = NAFNetROIRefiner(in_channels=7, out_channels=3, width=32)
    x = torch.randn(2, 7, 96, 96)
    y = model(x)
    print("input:", x.shape, "output:", y.shape)
    n_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"parameters: {n_params:.2f} M")
