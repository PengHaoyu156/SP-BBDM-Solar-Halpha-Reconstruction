#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Frozen-set test / inference script for NAFNet ROI residual refiner.

This script follows the frozen evaluation style used by test_solar_restormer_frozen.py.
It does NOT repeat solar-disk cropping, timestamp cleaning, or resizing.
It directly reads the frozen condition / ground_truth / SP-BBDM output images exported
by SP-BBDM sample_to_eval, converts them to [-1, 1], and evaluates REF on the exact
same frozen pixel space.

Expected frozen test structure:
  --test_a   sample_to_eval/condition       # frozen SP-BBDM condition images, AIA 304 Å
  --test_b   sample_to_eval/ground_truth    # frozen SP-BBDM GT H-alpha images
  --test_sp  SP-BBDM prediction folder      # frozen SP-BBDM generated H-alpha images

If A/B/SP filenames are identical, use:
  --match_mode name

If filenames differ but are in corresponding sorted order, use:
  --match_mode sorted
The full_sp and full_gt images are copied losslessly from the frozen folders using
GT filenames, so the SP baseline can be evaluated with the same frozen GT used for
SP-BBDM and other models.

Outputs:
  out_dir/full_refined/*.png            REF full-disk refined images
  out_dir/full_sp/*.png                 copied frozen SP-BBDM prediction images
  out_dir/full_gt/*.png                 copied frozen GT images
  out_dir/roi_patches/refined/*.png     refined ROI patches
  out_dir/metrics_roi.csv               per-ROI patch metrics
  out_dir/metrics_full.csv              per-image full-disk metrics
  out_dir/summary.txt                   mean metrics and winner counts
"""
from __future__ import annotations

import argparse
import csv
import math
import os
import random
import shutil
import textwrap
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from PIL import Image, ImageOps, ImageDraw, ImageFont

import torch
import torch.nn.functional as F
import torchvision.transforms as transforms
from torchvision.utils import make_grid, save_image
from tqdm.auto import tqdm

try:
    from nafnet_roi_refiner_standalone import NAFNetROIRefiner
except Exception as exc:
    raise ImportError(
        "Cannot import nafnet_roi_refiner_standalone.py. Please put it in the same folder as this test script."
    ) from exc

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}


# -----------------------------------------------------------------------------
# File matching
# -----------------------------------------------------------------------------
def list_images(folder: str | Path) -> List[Path]:
    folder = Path(folder)
    if not folder.exists():
        raise FileNotFoundError(f"Image folder not found: {folder}")
    return sorted([p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS])


def stem_map(paths: Sequence[Path]) -> Dict[str, Path]:
    return {p.stem: p for p in paths}


def build_triplets(
    a_dir: str | Path,
    b_dir: str | Path,
    sp_dir: str | Path,
    match_mode: str = "name",
) -> List[Tuple[Path, Path, Path, str, str]]:
    """
    Return tuples:
        (a_path, b_path, sp_path, stem, output_filename)

    output_filename is always based on the GT filename stem and forced to .png.
    In sorted mode, sorted A/B/SP files are paired by order, which is useful when
    SP-BBDM condition and ground_truth names differ but their order is fixed.
    """
    a_files = list_images(a_dir)
    b_files = list_images(b_dir)
    sp_files = list_images(sp_dir)

    if len(a_files) == 0:
        raise RuntimeError(f"No images found in test_a: {a_dir}")
    if len(b_files) == 0:
        raise RuntimeError(f"No images found in test_b: {b_dir}")
    if len(sp_files) == 0:
        raise RuntimeError(f"No images found in test_sp: {sp_dir}")

    pairs: List[Tuple[Path, Path, Path, str, str]] = []

    if match_mode == "name":
        a_map = stem_map(a_files)
        b_map = stem_map(b_files)
        sp_map = stem_map(sp_files)
        common = sorted(set(a_map) & set(b_map) & set(sp_map))
        if not common:
            raise RuntimeError(
                "No matched A/B/SP triplets by filename stem. "
                "If names differ but order matches, rerun with --match_mode sorted.\n"
                f"A={len(a_map)}, B={len(b_map)}, SP={len(sp_map)}\n"
                f"A_dir={a_dir}\nB_dir={b_dir}\nSP_dir={sp_dir}"
            )
        missing_a = len(a_map) - len(common)
        missing_b = len(b_map) - len(common)
        missing_sp = len(sp_map) - len(common)
        if missing_a or missing_b or missing_sp:
            print(
                f"[Warning] unmatched files ignored: "
                f"A_only/unused={missing_a}, B_only/unused={missing_b}, SP_only/unused={missing_sp}"
            )
        for k in common:
            out_name = b_map[k].stem + ".png"
            pairs.append((a_map[k], b_map[k], sp_map[k], k, out_name))

    elif match_mode == "sorted":
        n = min(len(a_files), len(b_files), len(sp_files))
        if len(a_files) != len(b_files) or len(a_files) != len(sp_files):
            print(
                f"[Warning] A/B/SP counts differ: A={len(a_files)}, B={len(b_files)}, SP={len(sp_files)}. "
                f"Pairing first {n} images by sorted order."
            )
        for a_path, b_path, sp_path in zip(a_files[:n], b_files[:n], sp_files[:n]):
            stem = b_path.stem
            out_name = b_path.stem + ".png"
            pairs.append((a_path, b_path, sp_path, stem, out_name))
    else:
        raise ValueError(f"Unknown match_mode: {match_mode}")

    return pairs

# -----------------------------------------------------------------------------
# Tensor / image helpers
# -----------------------------------------------------------------------------
def to_01(x: torch.Tensor) -> torch.Tensor:
    if float(x.min()) < -0.1:
        return ((x.clamp(-1, 1) + 1.0) / 2.0).clamp(0, 1)
    return x.clamp(0, 1)


def to_gray01(x: torch.Tensor) -> torch.Tensor:
    y = to_01(x)
    if y.shape[0] >= 3:
        return (0.299 * y[0:1] + 0.587 * y[1:2] + 0.114 * y[2:3]).clamp(0, 1)
    return y.mean(dim=0, keepdim=True).clamp(0, 1)


def tensor_to_save(x: torch.Tensor) -> torch.Tensor:
    return ((x.detach().cpu().clamp(-1, 1) + 1.0) / 2.0).clamp(0, 1)


def mask_to_save(m: torch.Tensor) -> torch.Tensor:
    if m.dim() == 3:
        m = m.unsqueeze(0)
    if m.shape[1] == 1:
        m = m.repeat(1, 3, 1, 1)
    return m.detach().cpu().clamp(0, 1)


def read_frozen_image_as_normalized_tensor(path: str | Path) -> torch.Tensor:
    """
    Read a frozen uint8 RGB image without crop/resize and convert it to [3,H,W] in [-1,1].
    """
    img = Image.open(path).convert("RGB")
    x = transforms.ToTensor()(img)
    return ((x - 0.5) * 2.0).clamp(-1.0, 1.0)


def tensor_minus1_1_to_uint8_image(x: torch.Tensor) -> Image.Image:
    """Convert [3,H,W] or [1,3,H,W] tensor in [-1,1] to PIL RGB uint8 image."""
    if x.ndim == 4:
        x = x[0]
    x = x.detach().float().cpu()
    x = torch.clamp((x + 1.0) * 0.5, 0.0, 1.0)
    arr = x.mul(255.0).add(0.5).clamp(0, 255).permute(1, 2, 0).to(torch.uint8).numpy()
    return Image.fromarray(arr)


def assert_same_shape(a: torch.Tensor, b: torch.Tensor, sp: torch.Tensor, a_path: Path, b_path: Path, sp_path: Path) -> None:
    if a.shape != b.shape or a.shape != sp.shape:
        raise RuntimeError(
            "Frozen A/B/SP shapes are not identical. This frozen REF script does not crop/resize.\n"
            f"A:  {a.shape}  {a_path}\n"
            f"B:  {b.shape}  {b_path}\n"
            f"SP: {sp.shape}  {sp_path}"
        )


# -----------------------------------------------------------------------------
# Solar disk crop and cleanup, consistent with the training script
# -----------------------------------------------------------------------------
def _bicubic_resample():
    try:
        return Image.Resampling.BICUBIC
    except AttributeError:
        return Image.BICUBIC


def estimate_disk_center_radius_stable(
    pil_img: Image.Image,
    thr_ratio: float = 0.2,
    sat_thr_core: float = 0.18,
) -> Tuple[float, float, float]:
    rgb = np.array(pil_img.convert("RGB"), dtype=np.float32) / 255.0
    h, w, _ = rgb.shape
    gray = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    cmax = rgb.max(axis=2)
    cmin = rgb.min(axis=2)
    sat = (cmax - cmin) / (cmax + 1e-6)

    maxv = float(gray.max()) if gray.size else 0.0
    if maxv <= 0.0:
        return w / 2.0, h / 2.0, min(h, w) / 2.2

    core_mask = (gray > (thr_ratio * maxv)) & (sat > sat_thr_core)
    ys, xs = np.where(core_mask)
    if ys.size < 50:
        ys, xs = np.where(gray > (thr_ratio * maxv))
    if ys.size < 10:
        return w / 2.0, h / 2.0, min(h, w) / 2.2

    cx = float(xs.mean())
    cy = float(ys.mean())

    bottom_cut = int(h * 0.90)
    radius_mask = (gray > (thr_ratio * maxv * 0.8)) & (sat > (sat_thr_core * 0.5))
    radius_mask[bottom_cut:, :] = False
    ys_r, xs_r = np.where(radius_mask)
    if ys_r.size < 10:
        ys_r, xs_r = ys, xs

    dists = np.sqrt((xs_r - cx) ** 2 + (ys_r - cy) ** 2)
    r = float(np.percentile(dists, 99) * 1.02)
    r = min(r, min(h, w) * 0.5)
    return cx, cy, r


def crop_and_normalize_disk(
    pil_img: Image.Image,
    out_size: int,
    flip: bool = False,
    to_normal: bool = True,
    thr_ratio: float = 0.2,
    radius_margin: float = 1.05,
) -> torch.Tensor:
    pil_img = pil_img.convert("RGB")
    cx, cy, r = estimate_disk_center_radius_stable(pil_img, thr_ratio=thr_ratio)

    side = int(np.ceil(2.0 * r * radius_margin))
    half = side // 2
    left = int(round(cx - half))
    top = int(round(cy - half))
    right = left + side
    bottom = top + side

    w, h = pil_img.size
    pad_left = max(0, -left)
    pad_top = max(0, -top)
    pad_right = max(0, right - w)
    pad_bottom = max(0, bottom - h)

    if pad_left or pad_top or pad_right or pad_bottom:
        canvas = Image.new("RGB", (w + pad_left + pad_right, h + pad_top + pad_bottom), (0, 0, 0))
        canvas.paste(pil_img, (pad_left, pad_top))
        left += pad_left
        right += pad_left
        top += pad_top
        bottom += pad_top
        pil_img = canvas

    crop = pil_img.crop((left, top, right, bottom))
    if flip:
        crop = ImageOps.mirror(crop)
    crop = crop.resize((out_size, out_size), resample=_bicubic_resample())

    tensor = transforms.ToTensor()(crop)

    # Clean up white labels/ticks outside the normalized disk.
    _, ht, wt = tensor.shape
    r_norm = out_size / (2.0 * radius_margin)
    yy = torch.arange(ht, dtype=torch.float32).view(ht, 1)
    xx = torch.arange(wt, dtype=torch.float32).view(1, wt)
    cy_n = (ht - 1) / 2.0
    cx_n = (wt - 1) / 2.0
    dist = torch.sqrt((yy - cy_n) ** 2 + (xx - cx_n) ** 2 + 1e-9)
    outside_disk = dist > (r_norm * 1.05)
    safe_outside = dist > (r_norm * 1.00)

    rch, gch, bch = tensor[0], tensor[1], tensor[2]
    gray = 0.299 * rch + 0.587 * gch + 0.114 * bch
    cmax = torch.maximum(torch.maximum(rch, gch), bch)
    cmin = torch.minimum(torch.minimum(rch, gch), bch)
    sat = (cmax - cmin) / (cmax + 1e-6)

    strict_white = (
        (gray > 0.4)
        & (sat < 0.3)
        & (torch.abs(rch - gch) < 0.15)
        & (torch.abs(rch - bch) < 0.15)
        & (torch.abs(gch - bch) < 0.15)
    )
    loose_white = (
        (gray > 0.30)
        & (sat < 0.40)
        & (torch.abs(rch - gch) < 0.20)
        & (torch.abs(rch - bch) < 0.20)
        & (torch.abs(gch - bch) < 0.20)
    )
    kill_outside = outside_disk & strict_white
    bottom_band = yy > (ht * 0.60)
    bottom_raw = bottom_band & (strict_white | loose_white) & safe_outside
    if bottom_raw.any():
        m = bottom_raw.float().unsqueeze(0).unsqueeze(0)
        kernel = torch.ones((1, 1, 3, 3), dtype=m.dtype)
        dilated = F.conv2d(m, kernel, padding=1)[0, 0] > 0
        bottom_raw = dilated & safe_outside
    kill = kill_outside | bottom_raw
    if kill.any():
        tensor[:, kill] = 0.0

    if to_normal:
        tensor = (tensor - 0.5) * 2.0
        tensor = tensor.clamp(-1.0, 1.0)
    return tensor


# -----------------------------------------------------------------------------
# ROI detection using A + SP only, NOT GT B
# -----------------------------------------------------------------------------
def disk_mask_hw(h: int, w: int, radius: float, margin: float = 1.0, device=None) -> torch.Tensor:
    yy, xx = torch.meshgrid(torch.arange(h, device=device), torch.arange(w, device=device), indexing="ij")
    cy = (h - 1) / 2.0
    cx = (w - 1) / 2.0
    r = float(radius) * float(margin)
    return (((yy - cy) ** 2 + (xx - cx) ** 2) <= r**2).float()


def sobel_magnitude(gray01: torch.Tensor) -> torch.Tensor:
    x = gray01.unsqueeze(0)
    kx = torch.tensor([[[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]], dtype=x.dtype, device=x.device).unsqueeze(1)
    ky = torch.tensor([[[-1, -2, -1], [0, 0, 0], [1, 2, 1]]], dtype=x.dtype, device=x.device).unsqueeze(1)
    gx = F.conv2d(x, kx, padding=1)
    gy = F.conv2d(x, ky, padding=1)
    return torch.sqrt(gx[0, 0] ** 2 + gy[0, 0] ** 2 + 1e-12)


def local_contrast(gray01: torch.Tensor, kernel_size: int = 9) -> torch.Tensor:
    x = gray01.unsqueeze(0)
    pad = kernel_size // 2
    mean = F.avg_pool2d(x, kernel_size=kernel_size, stride=1, padding=pad)
    return (x - mean).abs()[0, 0]


def normalize_inside(x: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    vals = x[mask]
    if vals.numel() == 0:
        return torch.zeros_like(x)
    lo = vals.min()
    hi = torch.quantile(vals, 0.995)
    return ((x - lo) / (hi - lo + eps)).clamp(0, 1)


def roi_components(
    img: torch.Tensor,
    disk_radius: float,
    detect_margin: float,
    bright_q: float,
    grad_q: float,
    contrast_q: float,
    min_pixels: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    gray = to_gray01(img)
    _, h, w = gray.shape
    disk = disk_mask_hw(h, w, disk_radius, detect_margin, device=gray.device).bool()
    vals = gray[0][disk]
    if vals.numel() < min_pixels:
        return torch.zeros_like(gray), torch.zeros_like(gray)

    grad = sobel_magnitude(gray)
    cont = local_contrast(gray, 9)
    bright_score = normalize_inside(gray[0], disk)
    grad_score = normalize_inside(grad, disk)
    cont_score = normalize_inside(cont, disk)

    bright_mask = (gray[0] >= torch.quantile(vals, bright_q)) & disk
    gvals = grad[disk]
    grad_mask = (grad >= torch.quantile(gvals, grad_q)) & disk if gvals.numel() >= min_pixels else torch.zeros_like(disk)
    cvals = cont[disk]
    cont_mask = (cont >= torch.quantile(cvals, contrast_q)) & disk if cvals.numel() >= min_pixels else torch.zeros_like(disk)

    mask = (bright_mask | grad_mask | cont_mask).float().unsqueeze(0)
    score = (0.45 * bright_score + 0.35 * grad_score + 0.20 * cont_score) * disk.float()
    score = score.unsqueeze(0)
    if mask.sum() < min_pixels:
        return torch.zeros_like(mask), torch.zeros_like(score)
    return mask, score


def build_roi_mask_and_score_infer(
    a_full: torch.Tensor,
    sp_full: torch.Tensor,
    roi_source: str,
    disk_radius: float,
    detect_margin: float,
    bright_q: float,
    grad_q: float,
    contrast_q: float,
    min_pixels: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Build ROI using only A and/or SP. Does not read GT B."""
    mask_a, score_a = roi_components(a_full, disk_radius, detect_margin, bright_q, grad_q, contrast_q, min_pixels)
    mask_sp, score_sp = roi_components(sp_full, disk_radius, detect_margin, bright_q, grad_q, contrast_q, min_pixels)
    src = roi_source.lower()

    if src in {"a", "source", "aia"}:
        return mask_a, score_a
    if src in {"sp", "coarse"}:
        return mask_sp, score_sp
    if src in {"a_sp_union", "union", "aligned_union"}:
        return (mask_a.bool() | mask_sp.bool()).float(), 0.5 * (score_a + score_sp)
    if src in {"a_sp_intersect", "intersect", "intersection"}:
        return (mask_a.bool() & mask_sp.bool()).float(), 0.5 * (score_a + score_sp)
    raise ValueError(
        f"Unknown roi_source for test: {roi_source}. Use one of: a, sp, a_sp_union, a_sp_intersect."
    )


def dilate_mask(mask: torch.Tensor, kernel_size: int) -> torch.Tensor:
    if kernel_size <= 1:
        return mask
    return F.max_pool2d(mask.unsqueeze(0).float(), kernel_size=kernel_size, stride=1, padding=kernel_size // 2)[0]


def soft_mask(mask: torch.Tensor, smooth_times: int = 2) -> torch.Tensor:
    x = mask.unsqueeze(0).float()
    for _ in range(smooth_times):
        x = F.avg_pool2d(x, kernel_size=5, stride=1, padding=2)
    return x[0].clamp(0, 1)


def crop_patch(x: torch.Tensor, cy: int, cx: int, patch_size: int) -> torch.Tensor:
    c, h, w = x.shape
    half = patch_size // 2
    cy = int(max(half, min(h - half - 1, int(cy))))
    cx = int(max(half, min(w - half - 1, int(cx))))
    y0 = cy - half
    x0 = cx - half
    return x[:, y0 : y0 + patch_size, x0 : x0 + patch_size]


def paste_patch(acc_res: torch.Tensor, acc_w: torch.Tensor, res_patch: torch.Tensor, mask_patch: torch.Tensor, cy: int, cx: int) -> None:
    """Accumulate residual patch into full-disk residual accumulator."""
    _, h, w = acc_res.shape
    patch_size = res_patch.shape[-1]
    half = patch_size // 2
    cy = int(max(half, min(h - half - 1, int(cy))))
    cx = int(max(half, min(w - half - 1, int(cx))))
    y0 = cy - half
    x0 = cx - half
    w_patch = mask_patch.clamp(0, 1)
    acc_res[:, y0:y0 + patch_size, x0:x0 + patch_size] += res_patch.detach().cpu() * w_patch.detach().cpu()
    acc_w[:, y0:y0 + patch_size, x0:x0 + patch_size] += w_patch.detach().cpu()


def choose_topk_center(
    mask: torch.Tensor,
    score: torch.Tensor,
    patch_size: int,
    disk_radius: float,
    center_margin: float,
    kth: int,
    min_pixels: int = 10,
) -> Tuple[int, int]:
    _, h, w = mask.shape
    center_disk = disk_mask_hw(h, w, disk_radius, center_margin, device=mask.device).bool()
    work = mask[0].float() * score[0].float() * center_disk.float()

    if int((work > 0).sum().item()) >= min_pixels:
        suppress_radius = max(patch_size // 2, 8)
        cy, cx = h // 2, w // 2
        for _ in range(kth + 1):
            if float(work.max().item()) <= 0:
                break
            flat = int(work.argmax().item())
            cy, cx = flat // w, flat % w
            y0, y1 = max(0, cy - suppress_radius), min(h, cy + suppress_radius + 1)
            x0, x1 = max(0, cx - suppress_radius), min(w, cx + suppress_radius + 1)
            work[y0:y1, x0:x1] = 0.0
        half = patch_size // 2
        return int(max(half, min(h - half - 1, cy))), int(max(half, min(w - half - 1, cx)))

    coords = torch.nonzero(center_disk, as_tuple=False)
    if coords.numel() > 0:
        cy, cx = coords[min(kth, coords.shape[0] - 1)].tolist()
        return int(cy), int(cx)
    return h // 2, w // 2


def build_coord_maps(h: int, w: int, disk_radius: float, dtype=torch.float32) -> Tuple[torch.Tensor, torch.Tensor]:
    yy, xx = torch.meshgrid(torch.arange(h, dtype=dtype), torch.arange(w, dtype=dtype), indexing="ij")
    cy = (h - 1) / 2.0
    cx = (w - 1) / 2.0
    coord_x = (xx - cx) / (disk_radius + 1e-6)
    coord_y = (yy - cy) / (disk_radius + 1e-6)
    return coord_x.unsqueeze(0), coord_y.unsqueeze(0)


# -----------------------------------------------------------------------------
# Metrics
# -----------------------------------------------------------------------------
def _expand_metric_mask(mask: Optional[torch.Tensor], like: torch.Tensor) -> Optional[torch.Tensor]:
    if mask is None:
        return None
    if mask.dim() == 3:
        mask = mask.unsqueeze(0)
    if mask.shape[1] == 1 and like.shape[1] != 1:
        return mask.expand(-1, like.shape[1], -1, -1)
    return mask


@torch.no_grad()
def mae_per_image(pred: torch.Tensor, target: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    err = (pred - target).abs()
    if mask is None:
        return err.flatten(1).mean(dim=1)
    w = _expand_metric_mask(mask.clamp(0, 1), err)
    return (err * w).flatten(1).sum(dim=1) / (w.flatten(1).sum(dim=1) + 1e-8)


@torch.no_grad()
def mse_per_image(pred: torch.Tensor, target: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    err = (pred - target).pow(2)
    if mask is None:
        return err.flatten(1).mean(dim=1)
    w = _expand_metric_mask(mask.clamp(0, 1), err)
    return (err * w).flatten(1).sum(dim=1) / (w.flatten(1).sum(dim=1) + 1e-8)


@torch.no_grad()
def psnr_from_mse(mse: torch.Tensor, data_range: float = 2.0) -> torch.Tensor:
    return 20.0 * torch.log10(torch.tensor(data_range, device=mse.device)) - 10.0 * torch.log10(mse.clamp_min(1e-12))


@torch.no_grad()
def _gray_for_metric(x: torch.Tensor) -> torch.Tensor:
    if x.shape[1] >= 3:
        return 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
    return x.mean(dim=1, keepdim=True)


@torch.no_grad()
def _sobel_mag_for_metric(x: torch.Tensor) -> torch.Tensor:
    g = _gray_for_metric(x)
    kx = torch.tensor([[[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]], dtype=g.dtype, device=g.device).unsqueeze(1)
    ky = torch.tensor([[[-1, -2, -1], [0, 0, 0], [1, 2, 1]]], dtype=g.dtype, device=g.device).unsqueeze(1)
    gx = F.conv2d(g, kx, padding=1)
    gy = F.conv2d(g, ky, padding=1)
    return torch.sqrt(gx.pow(2) + gy.pow(2) + 1e-12)


@torch.no_grad()
def _laplacian_for_metric(x: torch.Tensor) -> torch.Tensor:
    g = _gray_for_metric(x)
    k = torch.tensor([[[0, 1, 0], [1, -4, 1], [0, 1, 0]]], dtype=g.dtype, device=g.device).unsqueeze(1)
    return F.conv2d(g, k, padding=1)


@torch.no_grad()
def _high_freq_for_metric(x: torch.Tensor, kernel_size: int = 9) -> torch.Tensor:
    g = _gray_for_metric(x)
    mean = F.avg_pool2d(g, kernel_size=kernel_size, stride=1, padding=kernel_size // 2)
    return g - mean


@torch.no_grad()
def response_mae_per_image(pred_resp: torch.Tensor, target_resp: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    err = (pred_resp - target_resp).abs()
    if mask is None:
        return err.flatten(1).mean(dim=1)
    if mask.dim() == 3:
        mask = mask.unsqueeze(0)
    w = mask.clamp(0, 1)
    if w.shape[1] != err.shape[1]:
        w = w.expand(-1, err.shape[1], -1, -1)
    return (err * w).flatten(1).sum(dim=1) / (w.flatten(1).sum(dim=1) + 1e-8)


@torch.no_grad()
def compute_metric_dict(sp: torch.Tensor, refined: torch.Tensor, gt: torch.Tensor, mask: Optional[torch.Tensor] = None) -> Dict[str, float]:
    """sp/refined/gt: [1,3,H,W] in [-1,1]. mask optional [1,1,H,W]."""
    sp_mae = mae_per_image(sp, gt, None)[0]
    ref_mae = mae_per_image(refined, gt, None)[0]
    sp_psnr = psnr_from_mse(mse_per_image(sp, gt, None))[0]
    ref_psnr = psnr_from_mse(mse_per_image(refined, gt, None))[0]

    out = {
        "sp_mae": float(sp_mae.cpu()),
        "refined_mae": float(ref_mae.cpu()),
        "delta_mae_sp_minus_refined": float((sp_mae - ref_mae).cpu()),
        "sp_psnr": float(sp_psnr.cpu()),
        "refined_psnr": float(ref_psnr.cpu()),
        "delta_psnr_refined_minus_sp": float((ref_psnr - sp_psnr).cpu()),
        "winner_mae": "refined" if ref_mae < sp_mae else "SP",
    }

    if mask is not None:
        sp_roi_mae = mae_per_image(sp, gt, mask)[0]
        ref_roi_mae = mae_per_image(refined, gt, mask)[0]
        sp_roi_psnr = psnr_from_mse(mse_per_image(sp, gt, mask))[0]
        ref_roi_psnr = psnr_from_mse(mse_per_image(refined, gt, mask))[0]

        sp_grad, ref_grad, gt_grad = _sobel_mag_for_metric(sp), _sobel_mag_for_metric(refined), _sobel_mag_for_metric(gt)
        sp_lap, ref_lap, gt_lap = _laplacian_for_metric(sp), _laplacian_for_metric(refined), _laplacian_for_metric(gt)
        sp_hf, ref_hf, gt_hf = _high_freq_for_metric(sp), _high_freq_for_metric(refined), _high_freq_for_metric(gt)

        sp_grad_mae = response_mae_per_image(sp_grad, gt_grad, mask)[0]
        ref_grad_mae = response_mae_per_image(ref_grad, gt_grad, mask)[0]
        sp_lap_mae = response_mae_per_image(sp_lap, gt_lap, mask)[0]
        ref_lap_mae = response_mae_per_image(ref_lap, gt_lap, mask)[0]
        sp_hf_mae = response_mae_per_image(sp_hf, gt_hf, mask)[0]
        ref_hf_mae = response_mae_per_image(ref_hf, gt_hf, mask)[0]

        out.update({
            "sp_roi_mae": float(sp_roi_mae.cpu()),
            "refined_roi_mae": float(ref_roi_mae.cpu()),
            "delta_roi_mae_sp_minus_refined": float((sp_roi_mae - ref_roi_mae).cpu()),
            "sp_roi_psnr": float(sp_roi_psnr.cpu()),
            "refined_roi_psnr": float(ref_roi_psnr.cpu()),
            "delta_roi_psnr_refined_minus_sp": float((ref_roi_psnr - sp_roi_psnr).cpu()),
            "sp_roi_grad_mae": float(sp_grad_mae.cpu()),
            "refined_roi_grad_mae": float(ref_grad_mae.cpu()),
            "delta_roi_grad_mae_sp_minus_refined": float((sp_grad_mae - ref_grad_mae).cpu()),
            "sp_roi_lap_mae": float(sp_lap_mae.cpu()),
            "refined_roi_lap_mae": float(ref_lap_mae.cpu()),
            "delta_roi_lap_mae_sp_minus_refined": float((sp_lap_mae - ref_lap_mae).cpu()),
            "sp_roi_hf_mae": float(sp_hf_mae.cpu()),
            "refined_roi_hf_mae": float(ref_hf_mae.cpu()),
            "delta_roi_hf_mae_sp_minus_refined": float((sp_hf_mae - ref_hf_mae).cpu()),
            "winner_roi_mae": "refined" if ref_roi_mae < sp_roi_mae else "SP",
            "winner_roi_grad_mae": "refined" if ref_grad_mae < sp_grad_mae else "SP",
            "winner_roi_hf_mae": "refined" if ref_hf_mae < sp_hf_mae else "SP",
        })
    return out


# -----------------------------------------------------------------------------
# Preview saving
# -----------------------------------------------------------------------------
def _load_preview_font(size: int = 10):
    for fp in [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    ]:
        try:
            if os.path.exists(fp):
                return ImageFont.truetype(fp, size=size)
        except Exception:
            pass
    return ImageFont.load_default()


def save_grid_with_caption(rows: List[torch.Tensor], path: Path, caption: str = "") -> None:
    """Rows: list of [N,3,H,W] tensors in [0,1], stacked vertically."""
    row_imgs = []
    nrow = rows[0].shape[0]
    for row in rows:
        grid = make_grid(row.detach().cpu().clamp(0, 1), nrow=nrow, padding=2)
        row_imgs.append(grid)
    full = torch.cat(row_imgs, dim=1)  # concatenate along height
    arr = (full.permute(1, 2, 0).numpy() * 255.0).round().astype(np.uint8)
    img = Image.fromarray(arr)

    if caption:
        font = _load_preview_font(10)
        draw_tmp = ImageDraw.Draw(img)
        max_width = img.width - 12
        avg_char_w = max(draw_tmp.textlength("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", font=font) / 62.0, 5.0)
        width_chars = max(45, int(max_width / avg_char_w))
        lines = []
        for line in caption.split("\n"):
            lines.extend(textwrap.wrap(line, width=width_chars, break_long_words=False) or [line])
        line_h = 13
        pad = 6
        canvas = Image.new("RGB", (img.width, img.height + pad * 2 + line_h * len(lines)), (255, 255, 255))
        canvas.paste(img, (0, 0))
        draw = ImageDraw.Draw(canvas)
        y = img.height + pad
        for line in lines:
            draw.text((6, y), line, fill=(0, 0, 0), font=font)
            y += line_h
        img = canvas

    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path)


# -----------------------------------------------------------------------------
# Main test logic
# -----------------------------------------------------------------------------
def build_model_from_checkpoint(ckpt_path: Path, args, device: torch.device) -> Tuple[torch.nn.Module, Dict]:
    ckpt = torch.load(ckpt_path, map_location="cpu")
    train_args = ckpt.get("args", {})

    use_coord = bool(train_args.get("use_coord_channels", args.use_coord_channels))
    in_channels = 9 if use_coord else 7
    width = int(train_args.get("width", args.width))
    middle_blk_num = int(train_args.get("middle_blk_num", args.middle_blk_num))
    enc_blks = tuple(int(x) for x in str(train_args.get("enc_blks", args.enc_blks)).split(",") if x.strip())
    dec_blks = tuple(int(x) for x in str(train_args.get("dec_blks", args.dec_blks)).split(",") if x.strip())
    dropout = float(train_args.get("dropout", args.dropout))

    model = NAFNetROIRefiner(
        in_channels=in_channels,
        out_channels=3,
        width=width,
        middle_blk_num=middle_blk_num,
        enc_blk_nums=enc_blks,
        dec_blk_nums=dec_blks,
        drop_out_rate=dropout,
    ).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()

    meta = {
        "use_coord_channels": use_coord,
        "in_channels": in_channels,
        "width": width,
        "middle_blk_num": middle_blk_num,
        "enc_blks": enc_blks,
        "dec_blks": dec_blks,
        "dropout": dropout,
        "checkpoint_epoch": ckpt.get("epoch", None),
        "checkpoint_step": ckpt.get("step", None),
    }
    return model, meta


def run_test(args) -> None:
    # Resolve new frozen-style args and backward-compatible old aliases.
    test_a = args.test_a or args.test_a_dir
    test_b = args.test_b or args.test_b_dir
    test_sp = args.test_sp or args.test_sp_dir
    if test_a is None or test_b is None or test_sp is None:
        raise ValueError("Please provide --test_a/--test_b/--test_sp, or the old aliases --test_a_dir/--test_b_dir/--test_sp_dir.")

    out_dir = Path(args.out_dir)
    if args.clear_out_dir and out_dir.exists():
        print(f"[Clear] Removing existing out_dir to avoid stale files: {out_dir}")
        shutil.rmtree(out_dir)

    roi_dir = out_dir / "roi_patches"
    refined_patch_dir = roi_dir / "refined"
    sp_patch_dir = roi_dir / "sp"
    gt_patch_dir = roi_dir / "gt"
    aia_patch_dir = roi_dir / "aia"
    mask_patch_dir = roi_dir / "mask"
    full_refined_dir = out_dir / "full_refined"
    full_sp_dir = out_dir / "full_sp"
    full_gt_dir = out_dir / "full_gt"
    for d in [roi_dir, refined_patch_dir, sp_patch_dir, gt_patch_dir, aia_patch_dir, mask_patch_dir, full_refined_dir, full_sp_dir, full_gt_dir]:
        d.mkdir(parents=True, exist_ok=True)

    device = torch.device(args.device if torch.cuda.is_available() or "cuda" not in args.device else "cpu")
    model, meta = build_model_from_checkpoint(Path(args.checkpoint), args, device)

    triplets = build_triplets(test_a, test_b, test_sp, args.match_mode)
    use_coord = bool(meta["use_coord_channels"])

    print("=" * 80)
    print("NAFNet ROI Refiner Frozen Test")
    print(f"Matched frozen test images: {len(triplets)}")
    print(f"test_a / condition : {test_a}")
    print(f"test_b / GT        : {test_b}")
    print(f"test_sp / SP output: {test_sp}")
    print(f"match_mode         : {args.match_mode}")
    print(f"Checkpoint: {args.checkpoint}")
    print(f"Checkpoint epoch/step: {meta['checkpoint_epoch']} / {meta['checkpoint_step']}")
    print(f"Model input channels: {meta['in_channels']}  use_coord_channels={use_coord}")
    print(f"ROI source at test: {args.roi_source}  (uses A/SP only, not GT)")
    print("No crop/resize/timestamp cleaning is applied here.")
    print(f"Out dir: {out_dir}")
    print("=" * 80)

    roi_csv_path = out_dir / "metrics_roi.csv"
    full_csv_path = out_dir / "metrics_full.csv"
    roi_rows: List[Dict[str, object]] = []
    full_rows: List[Dict[str, object]] = []

    preview_count = 0

    with torch.no_grad():
        for a_path, b_path, sp_path, stem, out_name in tqdm(triplets, desc="Testing on frozen set", dynamic_ncols=True):
            # Frozen evaluation: read exact exported uint8 images; do not crop or resize.
            a_full = read_frozen_image_as_normalized_tensor(a_path)
            b_full = read_frozen_image_as_normalized_tensor(b_path)
            sp_full = read_frozen_image_as_normalized_tensor(sp_path)
            assert_same_shape(a_full, b_full, sp_full, a_path, b_path, sp_path)

            _, h, w = a_full.shape
            disk_radius = float(min(h, w)) / (2.0 * args.radius_margin)
            if use_coord:
                coord_x_full, coord_y_full = build_coord_maps(h, w, disk_radius)

            roi_mask, roi_score = build_roi_mask_and_score_infer(
                a_full, sp_full,
                roi_source=args.roi_source,
                disk_radius=disk_radius,
                detect_margin=args.roi_detect_disk_margin,
                bright_q=args.roi_bright_quantile,
                grad_q=args.roi_grad_quantile,
                contrast_q=args.roi_contrast_quantile,
                min_pixels=args.roi_min_pixels,
            )
            roi_mask = dilate_mask(roi_mask, args.roi_dilate_kernel)

            acc_res = torch.zeros_like(sp_full)
            acc_w = torch.zeros(1, h, w)

            patch_rows_for_preview = []
            for k in range(args.num_rois_per_image):
                cy, cx = choose_topk_center(
                    roi_mask,
                    roi_score,
                    patch_size=args.patch_size,
                    disk_radius=disk_radius,
                    center_margin=args.roi_center_disk_margin,
                    kth=k,
                    min_pixels=args.roi_min_pixels,
                )
                a_patch = crop_patch(a_full, cy, cx, args.patch_size)
                b_patch = crop_patch(b_full, cy, cx, args.patch_size)
                sp_patch = crop_patch(sp_full, cy, cx, args.patch_size)
                m_patch = crop_patch(roi_mask, cy, cx, args.patch_size)
                m_soft = soft_mask(m_patch, args.mask_smooth_times)

                cond_parts = [a_patch, sp_patch, m_soft]
                if use_coord:
                    cond_parts.append(crop_patch(coord_x_full, cy, cx, args.patch_size))
                    cond_parts.append(crop_patch(coord_y_full, cy, cx, args.patch_size))
                condition = torch.cat(cond_parts, dim=0).unsqueeze(0).to(device)

                pred_res = model(condition).detach().cpu()[0]
                refined_patch = (sp_patch + m_soft * pred_res).clamp(-1.0, 1.0)
                paste_patch(acc_res, acc_w, pred_res, m_soft, cy, cx)

                # Metrics for this ROI patch.
                metrics = compute_metric_dict(
                    sp_patch.unsqueeze(0), refined_patch.unsqueeze(0), b_patch.unsqueeze(0), m_soft.unsqueeze(0)
                )
                row = {
                    "name": stem,
                    "roi_index": k,
                    "cy": cy,
                    "cx": cx,
                    **metrics,
                }
                roi_rows.append(row)

                patch_name = f"{Path(out_name).stem}_roi{k}_y{cy}_x{cx}.png"
                if args.save_roi_patches:
                    save_image(tensor_to_save(refined_patch), refined_patch_dir / patch_name)
                    save_image(tensor_to_save(sp_patch), sp_patch_dir / patch_name)
                    save_image(tensor_to_save(b_patch), gt_patch_dir / patch_name)
                    save_image(tensor_to_save(a_patch), aia_patch_dir / patch_name)
                    save_image(mask_to_save(m_soft.unsqueeze(0))[0], mask_patch_dir / patch_name)

                if preview_count < args.max_preview_images and k < args.preview_rois_per_image:
                    patch_rows_for_preview.append((a_patch, sp_patch, m_soft, refined_patch, b_patch, metrics, k, cy, cx))

            # Full-disk refined by averaged residuals over selected ROI patches.
            avg_res = acc_res / acc_w.clamp_min(1e-8)
            used_mask = (acc_w > 1e-8).float().clamp(0, 1)
            refined_full = (sp_full + used_mask * avg_res).clamp(-1.0, 1.0)

            full_metrics = compute_metric_dict(
                sp_full.unsqueeze(0), refined_full.unsqueeze(0), b_full.unsqueeze(0), used_mask.unsqueeze(0)
            )
            full_rows.append({"name": stem, **full_metrics})

            if args.save_full_images:
                # Save refined prediction as uint8 PNG. Copy frozen SP and GT losslessly
                # so full_sp/full_gt remain identical to the frozen evaluation files.
                tensor_minus1_1_to_uint8_image(refined_full).save(full_refined_dir / out_name)
                shutil.copy2(sp_path, full_sp_dir / out_name)
                shutil.copy2(b_path, full_gt_dir / out_name)

            if patch_rows_for_preview and preview_count < args.max_preview_images:
                n = len(patch_rows_for_preview)
                rows_t = []
                rows_t.append(torch.stack([tensor_to_save(x[0]) for x in patch_rows_for_preview], dim=0))  # AIA
                rows_t.append(torch.stack([tensor_to_save(x[1]) for x in patch_rows_for_preview], dim=0))  # SP
                rows_t.append(torch.stack([mask_to_save(x[2].unsqueeze(0))[0] for x in patch_rows_for_preview], dim=0))
                rows_t.append(torch.stack([tensor_to_save(x[3]) for x in patch_rows_for_preview], dim=0))  # refined
                rows_t.append(torch.stack([tensor_to_save(x[4]) for x in patch_rows_for_preview], dim=0))  # GT

                mean_roi_mae_sp = float(np.mean([x[5]["sp_roi_mae"] for x in patch_rows_for_preview]))
                mean_roi_mae_ref = float(np.mean([x[5]["refined_roi_mae"] for x in patch_rows_for_preview]))
                mean_grad_sp = float(np.mean([x[5]["sp_roi_grad_mae"] for x in patch_rows_for_preview]))
                mean_grad_ref = float(np.mean([x[5]["refined_roi_grad_mae"] for x in patch_rows_for_preview]))
                mean_hf_sp = float(np.mean([x[5]["sp_roi_hf_mae"] for x in patch_rows_for_preview]))
                mean_hf_ref = float(np.mean([x[5]["refined_roi_hf_mae"] for x in patch_rows_for_preview]))
                win_mae = sum(1 for x in patch_rows_for_preview if x[5]["winner_roi_mae"] == "refined")
                caption = (
                    f"{stem} | ROI source={args.roi_source} | rows: AIA / SP / mask / refined / GT\n"
                    f"ROI_MAE SP={mean_roi_mae_sp:.5f}, Ref={mean_roi_mae_ref:.5f}, Δ={mean_roi_mae_sp-mean_roi_mae_ref:.5f}, winner=refined {win_mae}/{n}\n"
                    f"ROI_GradMAE SP={mean_grad_sp:.5f}, Ref={mean_grad_ref:.5f}, Δ={mean_grad_sp-mean_grad_ref:.5f}; "
                    f"ROI_HFMAE SP={mean_hf_sp:.5f}, Ref={mean_hf_ref:.5f}, Δ={mean_hf_sp-mean_hf_ref:.5f}\n"
                    "Positive Δ for MAE/GradMAE/HFMAE means refined is closer to GT."
                )
                save_grid_with_caption(rows_t, roi_dir / f"preview_{preview_count:04d}_{Path(out_name).stem}.png", caption=caption)
                preview_count += 1

    # Save CSVs.
    if roi_rows:
        with roi_csv_path.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(roi_rows[0].keys()))
            writer.writeheader()
            writer.writerows(roi_rows)
    if full_rows:
        with full_csv_path.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(full_rows[0].keys()))
            writer.writeheader()
            writer.writerows(full_rows)

    # Summary.
    def mean_of(rows: List[Dict[str, object]], key: str) -> float:
        vals = [float(r[key]) for r in rows if key in r]
        return float(np.mean(vals)) if vals else float("nan")

    def count_winner(rows: List[Dict[str, object]], key: str) -> Tuple[int, int]:
        vals = [r.get(key, None) for r in rows]
        vals = [v for v in vals if v is not None]
        return sum(1 for v in vals if v == "refined"), len(vals)

    roi_win, roi_n = count_winner(roi_rows, "winner_roi_mae")
    full_win, full_n = count_winner(full_rows, "winner_mae")
    grad_win, grad_n = count_winner(roi_rows, "winner_roi_grad_mae")
    hf_win, hf_n = count_winner(roi_rows, "winner_roi_hf_mae")

    summary = [
        "NAFNet ROI Refiner Frozen Test Summary",
        "=" * 60,
        f"checkpoint: {args.checkpoint}",
        f"test images: {len(triplets)}",
        f"ROI source: {args.roi_source}  (A/SP only; GT is not used for ROI selection)",
        f"num_rois_per_image: {args.num_rois_per_image}",
        f"patch_size: {args.patch_size}",
        "",
        "ROI patch metrics:",
        f"  mean SP ROI MAE      = {mean_of(roi_rows, 'sp_roi_mae'):.6f}",
        f"  mean Ref ROI MAE     = {mean_of(roi_rows, 'refined_roi_mae'):.6f}",
        f"  mean ΔROI_MAE        = {mean_of(roi_rows, 'delta_roi_mae_sp_minus_refined'):.6f}  # positive means refined better",
        f"  winner ROI MAE       = refined {roi_win}/{roi_n}",
        f"  mean SP ROI GradMAE  = {mean_of(roi_rows, 'sp_roi_grad_mae'):.6f}",
        f"  mean Ref ROI GradMAE = {mean_of(roi_rows, 'refined_roi_grad_mae'):.6f}",
        f"  mean ΔROI_GradMAE    = {mean_of(roi_rows, 'delta_roi_grad_mae_sp_minus_refined'):.6f}",
        f"  winner ROI GradMAE   = refined {grad_win}/{grad_n}",
        f"  mean SP ROI HFMAE    = {mean_of(roi_rows, 'sp_roi_hf_mae'):.6f}",
        f"  mean Ref ROI HFMAE   = {mean_of(roi_rows, 'refined_roi_hf_mae'):.6f}",
        f"  mean ΔROI_HFMAE      = {mean_of(roi_rows, 'delta_roi_hf_mae_sp_minus_refined'):.6f}",
        f"  winner ROI HFMAE     = refined {hf_win}/{hf_n}",
        f"  mean SP ROI PSNR     = {mean_of(roi_rows, 'sp_roi_psnr'):.3f}",
        f"  mean Ref ROI PSNR    = {mean_of(roi_rows, 'refined_roi_psnr'):.3f}",
        f"  mean ΔROI_PSNR       = {mean_of(roi_rows, 'delta_roi_psnr_refined_minus_sp'):.3f}",
        "",
        "Full-disk metrics after ROI blending:",
        f"  mean SP MAE          = {mean_of(full_rows, 'sp_mae'):.6f}",
        f"  mean Ref MAE         = {mean_of(full_rows, 'refined_mae'):.6f}",
        f"  mean ΔMAE            = {mean_of(full_rows, 'delta_mae_sp_minus_refined'):.6f}",
        f"  winner full MAE      = refined {full_win}/{full_n}",
        f"  mean SP PSNR         = {mean_of(full_rows, 'sp_psnr'):.3f}",
        f"  mean Ref PSNR        = {mean_of(full_rows, 'refined_psnr'):.3f}",
        f"  mean ΔPSNR           = {mean_of(full_rows, 'delta_psnr_refined_minus_sp'):.3f}",
        "",
        f"ROI metrics CSV:  {roi_csv_path}",
        f"Full metrics CSV: {full_csv_path}",
    ]
    summary_text = "\n".join(summary)
    (out_dir / "summary.txt").write_text(summary_text, encoding="utf-8")
    print(summary_text)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Test NAFNet ROI residual refiner on frozen SP-BBDM sample_to_eval images.")

    # Frozen-style arguments, aligned with test_solar_restormer_frozen.py.
    p.add_argument("--test_a", default=None, help="Frozen SP-BBDM condition folder, e.g. sample_to_eval/condition")
    p.add_argument("--test_b", default=None, help="Frozen SP-BBDM GT folder, e.g. sample_to_eval/ground_truth")
    p.add_argument("--test_sp", default=None, help="Frozen SP-BBDM prediction folder to be refined")

    # Backward-compatible aliases from the old REF test script.
    p.add_argument("--test_a_dir", default=None)
    p.add_argument("--test_b_dir", default=None)
    p.add_argument("--test_sp_dir", default=None)

    p.add_argument("--checkpoint", required=True)
    p.add_argument("--out_dir", required=True)
    p.add_argument("--match_mode", choices=["name", "sorted"], default="name",
                   help="Use 'name' if A/B/SP share stems; use 'sorted' if filenames differ but order matches.")
    p.add_argument("--clear_out_dir", action="store_true",
                   help="Remove out_dir before testing to avoid stale files from previous runs.")

    p.add_argument("--patch_size", type=int, default=96)
    p.add_argument("--full_image_size", type=int, default=256,
                   help="Kept for command compatibility only. Frozen script uses the actual image size and does not resize.")
    p.add_argument("--num_rois_per_image", type=int, default=4)
    p.add_argument("--roi_source", type=str, default="a_sp_union", choices=["a", "source", "aia", "sp", "coarse", "a_sp_union", "union", "aligned_union", "a_sp_intersect", "intersect"])
    p.add_argument("--roi_bright_quantile", type=float, default=0.95)
    p.add_argument("--roi_grad_quantile", type=float, default=0.97)
    p.add_argument("--roi_contrast_quantile", type=float, default=0.97)
    p.add_argument("--roi_dilate_kernel", type=int, default=5)
    p.add_argument("--roi_min_pixels", type=int, default=10)
    p.add_argument("--roi_detect_disk_margin", type=float, default=0.90)
    p.add_argument("--roi_center_disk_margin", type=float, default=0.55)
    p.add_argument("--radius_margin", type=float, default=1.05)
    p.add_argument("--disk_thr_ratio", type=float, default=0.2,
                   help="Kept for compatibility only. No solar-disk crop is performed in frozen mode.")
    p.add_argument("--mask_smooth_times", type=int, default=2)
    p.add_argument("--use_coord_channels", action="store_true", help="Only used when checkpoint does not contain training args.")

    # Model defaults are fallback only. The script normally reads model config from checkpoint['args'].
    p.add_argument("--width", type=int, default=32)
    p.add_argument("--middle_blk_num", type=int, default=4)
    p.add_argument("--enc_blks", type=str, default="2,2,4")
    p.add_argument("--dec_blks", type=str, default="2,2,2")
    p.add_argument("--dropout", type=float, default=0.0)

    p.add_argument("--device", type=str, default="cuda:0")
    p.add_argument("--save_roi_patches", action="store_true")
    p.add_argument("--save_full_images", action="store_true")
    p.add_argument("--max_preview_images", type=int, default=20)
    p.add_argument("--preview_rois_per_image", type=int, default=4)
    return p.parse_args()

if __name__ == "__main__":
    run_test(parse_args())
