#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Train a frozen-version NAFNet-style ROI residual refiner for solar AIA 304 Å -> H-alpha refinement.

This script is designed for the SP-BBDM frozen test/training format. It does NOT
repeat solar-disk cropping, resizing, timestamp cleaning, or outside-disk cleanup.
It directly reads frozen uint8 RGB images exported by SP-BBDM sample_to_eval,
normalizes them to [-1, 1], detects ROI patches on the frozen tensors, and trains
the ROI residual refiner on the same distribution used at frozen evaluation time.

Task
----
Input condition:
    concat(frozen_AIA_patch, frozen_SP_BBDM_patch, ROI_soft_mask[, coord_x, coord_y])
Output:
    residual_pred = frozen_Halpha_GT_patch - frozen_SP_BBDM_patch
Final preview:
    refined_patch = frozen_SP_BBDM_patch + ROI_soft_mask * residual_pred

Expected frozen folder structure
--------------------------------
train:
    train/A or sample_to_eval/condition       frozen AIA condition images
    train/B or sample_to_eval/ground_truth    frozen H-alpha GT images
    train/SP or sample_to_eval/200            frozen SP-BBDM generated images
val optional:
    val/A
    val/B
    val/SP

If A/B/SP filenames share stems, use --match_mode name.
If filenames differ but sorted order corresponds, use --match_mode sorted.

Experiment-C loss is retained:
    Sobel-magnitude loss, optional small LPIPS loss, and residual magnitude
    regularization for improving gradient/perceptual consistency while limiting
    over-aggressive ROI residual corrections.
"""

from __future__ import annotations

import argparse
import csv
import math
import os
import random
import shutil
import sys
import textwrap
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from PIL import Image, ImageOps, ImageDraw, ImageFont

import torch
import torch.nn.functional as F
from torch import nn
from torch.utils.data import DataLoader, Dataset, random_split
import torchvision.transforms as transforms
from torchvision.utils import make_grid, save_image
from tqdm.auto import tqdm

# The model file should be placed in the same folder as this training script,
# or the folder should be added to PYTHONPATH.
try:
    from nafnet_roi_refiner_standalone import NAFNetROIRefiner
except Exception as exc:
    raise ImportError(
        "Cannot import nafnet_roi_refiner_standalone.py. Please put "
        "nafnet_roi_refiner_standalone.py in the same directory as this script."
    ) from exc


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}


# -----------------------------------------------------------------------------
# Basic utilities
# -----------------------------------------------------------------------------
def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def list_images(folder: str | Path) -> List[Path]:
    folder = Path(folder)
    if not folder.exists():
        raise FileNotFoundError(f"Image folder not found: {folder}")
    paths = [p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    return sorted(paths)


def stem_map(paths: Sequence[Path]) -> Dict[str, Path]:
    return {p.stem: p for p in paths}


def match_triplets(
    a_dir: str | Path,
    b_dir: str | Path,
    sp_dir: str | Path,
    match_mode: str = "name",
) -> List[Tuple[Path, Path, Path, str]]:
    """Match frozen A/B/SP images.

    name mode: match by filename stem.
    sorted mode: pair sorted A/B/SP lists by order; output stem uses GT filename.
    """
    a_paths = list_images(a_dir)
    b_paths = list_images(b_dir)
    sp_paths = list_images(sp_dir)

    if match_mode == "name":
        a_map = stem_map(a_paths)
        b_map = stem_map(b_paths)
        sp_map = stem_map(sp_paths)
        common = sorted(set(a_map) & set(b_map) & set(sp_map))
        if not common:
            raise RuntimeError(
                f"No matched A/B/SP triplets found by filename stem.\n"
                f"A={len(a_map)}, B={len(b_map)}, SP={len(sp_map)}\n"
                f"A_dir={a_dir}\nB_dir={b_dir}\nSP_dir={sp_dir}\n"
                f"If filenames differ but order corresponds, use --match_mode sorted."
            )
        return [(a_map[k], b_map[k], sp_map[k], k) for k in common]

    if match_mode == "sorted":
        n = min(len(a_paths), len(b_paths), len(sp_paths))
        if n == 0:
            raise RuntimeError(
                f"No images found for sorted matching. A={len(a_paths)}, B={len(b_paths)}, SP={len(sp_paths)}"
            )
        if len(a_paths) != len(b_paths) or len(a_paths) != len(sp_paths):
            print(
                f"[Warning] A/B/SP counts differ: A={len(a_paths)}, B={len(b_paths)}, SP={len(sp_paths)}. "
                f"Pairing the first {n} images by sorted order."
            )
        triplets = []
        for ap, bp, sp in zip(a_paths[:n], b_paths[:n], sp_paths[:n]):
            # Use GT stem as canonical stem so saved previews/metrics match frozen GT naming.
            triplets.append((ap, bp, sp, bp.stem))
        return triplets

    raise ValueError(f"Unknown match_mode: {match_mode}")


def read_frozen_image_as_normalized_tensor(
    path: str | Path,
    expected_size: int = 256,
    flip: bool = False,
    to_normal: bool = True,
) -> torch.Tensor:
    """Read a frozen uint8 RGB image without crop/resize/cleanup.

    Frozen images are assumed to be exported by SP-BBDM sample_to_eval.
    The function converts PIL RGB -> tensor [0,1] -> optionally [-1,1].
    It intentionally does not change geometry.
    """
    img = Image.open(path).convert("RGB")
    if expected_size > 0 and img.size != (expected_size, expected_size):
        raise ValueError(
            f"Frozen image size mismatch for {path}: got {img.size}, expected "
            f"({expected_size}, {expected_size}). This frozen trainer intentionally does not resize. "
            f"Set --full_image_size to the frozen image size, or rebuild the frozen set."
        )
    if flip:
        img = ImageOps.mirror(img)
    tensor = transforms.ToTensor()(img)
    if to_normal:
        tensor = (tensor - 0.5) * 2.0
        tensor = tensor.clamp(-1.0, 1.0)
    return tensor


def to_01(x: torch.Tensor) -> torch.Tensor:
    """Convert CHW tensor in [-1,1] or [0,1] approximately to [0,1]."""
    if float(x.min()) < -0.1:
        return ((x.clamp(-1, 1) + 1.0) / 2.0).clamp(0, 1)
    return x.clamp(0, 1)


def to_gray01(x: torch.Tensor) -> torch.Tensor:
    """x: [3,H,W] in [-1,1] or [0,1]. Return [1,H,W] in [0,1]."""
    y = to_01(x)
    if y.shape[0] >= 3:
        return (0.299 * y[0:1] + 0.587 * y[1:2] + 0.114 * y[2:3]).clamp(0, 1)
    return y.mean(dim=0, keepdim=True).clamp(0, 1)


def tensor_to_save(x: torch.Tensor) -> torch.Tensor:
    """Convert tensor in [-1,1] to [0,1] for save_image."""
    return ((x.detach().cpu().clamp(-1, 1) + 1.0) / 2.0).clamp(0, 1)


def mask_to_save(m: torch.Tensor) -> torch.Tensor:
    if m.shape[1] == 1:
        m = m.repeat(1, 3, 1, 1)
    return m.detach().cpu().clamp(0, 1)


# -----------------------------------------------------------------------------
# Preview metrics: compare SP-BBDM coarse vs NAFNet refined against GT
# -----------------------------------------------------------------------------
def _expand_metric_mask(mask: Optional[torch.Tensor], like: torch.Tensor) -> Optional[torch.Tensor]:
    if mask is None:
        return None
    if mask.shape[1] == 1 and like.shape[1] != 1:
        return mask.expand(-1, like.shape[1], -1, -1)
    return mask


@torch.no_grad()
def mae_per_image(pred: torch.Tensor, target: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    """Return per-image MAE. pred/target: [B,C,H,W], mask optional [B,1,H,W]."""
    err = (pred - target).abs()
    if mask is None:
        return err.flatten(1).mean(dim=1)
    w = _expand_metric_mask(mask.clamp(0, 1), err)
    return (err * w).flatten(1).sum(dim=1) / (w.flatten(1).sum(dim=1) + 1e-8)


@torch.no_grad()
def mse_per_image(pred: torch.Tensor, target: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    """Return per-image MSE. pred/target are expected in [-1,1]."""
    err2 = (pred - target).pow(2)
    if mask is None:
        return err2.flatten(1).mean(dim=1)
    w = _expand_metric_mask(mask.clamp(0, 1), err2)
    return (err2 * w).flatten(1).sum(dim=1) / (w.flatten(1).sum(dim=1) + 1e-8)


@torch.no_grad()
def psnr_from_mse(mse: torch.Tensor, data_range: float = 2.0) -> torch.Tensor:
    """PSNR for tensors normalized to [-1,1], so data_range=2."""
    return 20.0 * torch.log10(torch.tensor(data_range, device=mse.device)) - 10.0 * torch.log10(mse.clamp_min(1e-12))



@torch.no_grad()
def _gray_for_metric(x: torch.Tensor) -> torch.Tensor:
    """Convert [-1,1] RGB tensor [B,C,H,W] to grayscale [B,1,H,W]."""
    if x.shape[1] >= 3:
        return 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
    return x.mean(dim=1, keepdim=True)


@torch.no_grad()
def _sobel_mag_for_metric(x: torch.Tensor) -> torch.Tensor:
    """Sobel magnitude of grayscale image. Input x is RGB/gray in [-1,1]."""
    g = _gray_for_metric(x)
    kx = torch.tensor(
        [[[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]],
        dtype=g.dtype,
        device=g.device,
    ).unsqueeze(1)
    ky = torch.tensor(
        [[[-1, -2, -1], [0, 0, 0], [1, 2, 1]]],
        dtype=g.dtype,
        device=g.device,
    ).unsqueeze(1)
    gx = F.conv2d(g, kx, padding=1)
    gy = F.conv2d(g, ky, padding=1)
    return torch.sqrt(gx.pow(2) + gy.pow(2) + 1e-12)


@torch.no_grad()
def _laplacian_for_metric(x: torch.Tensor) -> torch.Tensor:
    """Laplacian response of grayscale image. Input x is RGB/gray in [-1,1]."""
    g = _gray_for_metric(x)
    k = torch.tensor(
        [[[0, 1, 0], [1, -4, 1], [0, 1, 0]]],
        dtype=g.dtype,
        device=g.device,
    ).unsqueeze(1)
    return F.conv2d(g, k, padding=1)


@torch.no_grad()
def _high_freq_for_metric(x: torch.Tensor, kernel_size: int = 9) -> torch.Tensor:
    """High-frequency component x - local mean, computed on grayscale."""
    g = _gray_for_metric(x)
    pad = kernel_size // 2
    mean = F.avg_pool2d(g, kernel_size=kernel_size, stride=1, padding=pad)
    return g - mean


@torch.no_grad()
def response_mae_per_image(pred_resp: torch.Tensor, target_resp: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    """MAE for single-channel response maps, optionally inside ROI mask."""
    err = (pred_resp - target_resp).abs()
    if mask is None:
        return err.flatten(1).mean(dim=1)
    w = mask.clamp(0, 1)
    if w.shape[1] != err.shape[1]:
        w = w.expand(-1, err.shape[1], -1, -1)
    return (err * w).flatten(1).sum(dim=1) / (w.flatten(1).sum(dim=1) + 1e-8)


@torch.no_grad()
def append_preview_metrics(
    preview_dir: Path,
    step_or_epoch: int,
    names: Sequence[str],
    sp: torch.Tensor,
    refined: torch.Tensor,
    gt: torch.Tensor,
    mask: torch.Tensor,
) -> Dict[str, float]:
    """
    Append preview metrics to previews/preview_metrics.csv.

    Positive delta_mae / delta_roi_mae means refined is better than SP.
    Positive delta_psnr / delta_roi_psnr means refined is better than SP.

    Extra sharpness/texture diagnostics:
      - ROI GradMAE: MAE between Sobel-gradient magnitude maps, lower is better.
      - ROI LapMAE:  MAE between Laplacian response maps, lower is better.
      - ROI HFMAE:   MAE between high-frequency residual maps, lower is better.

    These extra metrics are useful because MAE can prefer a slightly smoother image.
    """
    preview_dir.mkdir(parents=True, exist_ok=True)
    metrics_csv = preview_dir / "preview_metrics.csv"
    summary_txt = preview_dir / "preview_metrics_latest.txt"

    sp = sp.detach()
    refined = refined.detach()
    gt = gt.detach()
    mask = mask.detach().clamp(0, 1)

    sp_mae = mae_per_image(sp, gt, None)
    ref_mae = mae_per_image(refined, gt, None)
    sp_roi_mae = mae_per_image(sp, gt, mask)
    ref_roi_mae = mae_per_image(refined, gt, mask)

    sp_psnr = psnr_from_mse(mse_per_image(sp, gt, None))
    ref_psnr = psnr_from_mse(mse_per_image(refined, gt, None))
    sp_roi_psnr = psnr_from_mse(mse_per_image(sp, gt, mask))
    ref_roi_psnr = psnr_from_mse(mse_per_image(refined, gt, mask))

    # Detail-sensitive response metrics. Lower is better for all of these MAEs.
    sp_grad = _sobel_mag_for_metric(sp)
    ref_grad = _sobel_mag_for_metric(refined)
    gt_grad = _sobel_mag_for_metric(gt)
    sp_roi_grad_mae = response_mae_per_image(sp_grad, gt_grad, mask)
    ref_roi_grad_mae = response_mae_per_image(ref_grad, gt_grad, mask)

    sp_lap = _laplacian_for_metric(sp)
    ref_lap = _laplacian_for_metric(refined)
    gt_lap = _laplacian_for_metric(gt)
    sp_roi_lap_mae = response_mae_per_image(sp_lap, gt_lap, mask)
    ref_roi_lap_mae = response_mae_per_image(ref_lap, gt_lap, mask)

    sp_hf = _high_freq_for_metric(sp)
    ref_hf = _high_freq_for_metric(refined)
    gt_hf = _high_freq_for_metric(gt)
    sp_roi_hf_mae = response_mae_per_image(sp_hf, gt_hf, mask)
    ref_roi_hf_mae = response_mae_per_image(ref_hf, gt_hf, mask)

    rows = []
    n = sp.shape[0]
    for i in range(n):
        name_i = str(names[i]) if i < len(names) else f"sample_{i}"
        rows.append({
            "step": int(step_or_epoch),
            "index": i,
            "name": name_i,
            "sp_mae": float(sp_mae[i].cpu()),
            "refined_mae": float(ref_mae[i].cpu()),
            "delta_mae_sp_minus_refined": float((sp_mae[i] - ref_mae[i]).cpu()),
            "sp_roi_mae": float(sp_roi_mae[i].cpu()),
            "refined_roi_mae": float(ref_roi_mae[i].cpu()),
            "delta_roi_mae_sp_minus_refined": float((sp_roi_mae[i] - ref_roi_mae[i]).cpu()),
            "sp_psnr": float(sp_psnr[i].cpu()),
            "refined_psnr": float(ref_psnr[i].cpu()),
            "delta_psnr_refined_minus_sp": float((ref_psnr[i] - sp_psnr[i]).cpu()),
            "sp_roi_psnr": float(sp_roi_psnr[i].cpu()),
            "refined_roi_psnr": float(ref_roi_psnr[i].cpu()),
            "delta_roi_psnr_refined_minus_sp": float((ref_roi_psnr[i] - sp_roi_psnr[i]).cpu()),
            "sp_roi_grad_mae": float(sp_roi_grad_mae[i].cpu()),
            "refined_roi_grad_mae": float(ref_roi_grad_mae[i].cpu()),
            "delta_roi_grad_mae_sp_minus_refined": float((sp_roi_grad_mae[i] - ref_roi_grad_mae[i]).cpu()),
            "sp_roi_lap_mae": float(sp_roi_lap_mae[i].cpu()),
            "refined_roi_lap_mae": float(ref_roi_lap_mae[i].cpu()),
            "delta_roi_lap_mae_sp_minus_refined": float((sp_roi_lap_mae[i] - ref_roi_lap_mae[i]).cpu()),
            "sp_roi_hf_mae": float(sp_roi_hf_mae[i].cpu()),
            "refined_roi_hf_mae": float(ref_roi_hf_mae[i].cpu()),
            "delta_roi_hf_mae_sp_minus_refined": float((sp_roi_hf_mae[i] - ref_roi_hf_mae[i]).cpu()),
            "winner_mae": "refined" if ref_mae[i] < sp_mae[i] else "SP",
            "winner_roi_mae": "refined" if ref_roi_mae[i] < sp_roi_mae[i] else "SP",
            "winner_roi_grad_mae": "refined" if ref_roi_grad_mae[i] < sp_roi_grad_mae[i] else "SP",
            "winner_roi_hf_mae": "refined" if ref_roi_hf_mae[i] < sp_roi_hf_mae[i] else "SP",
        })

    mean_row = {
        "step": int(step_or_epoch),
        "index": -1,
        "name": "MEAN",
        "sp_mae": float(sp_mae.mean().cpu()),
        "refined_mae": float(ref_mae.mean().cpu()),
        "delta_mae_sp_minus_refined": float((sp_mae - ref_mae).mean().cpu()),
        "sp_roi_mae": float(sp_roi_mae.mean().cpu()),
        "refined_roi_mae": float(ref_roi_mae.mean().cpu()),
        "delta_roi_mae_sp_minus_refined": float((sp_roi_mae - ref_roi_mae).mean().cpu()),
        "sp_psnr": float(sp_psnr.mean().cpu()),
        "refined_psnr": float(ref_psnr.mean().cpu()),
        "delta_psnr_refined_minus_sp": float((ref_psnr - sp_psnr).mean().cpu()),
        "sp_roi_psnr": float(sp_roi_psnr.mean().cpu()),
        "refined_roi_psnr": float(ref_roi_psnr.mean().cpu()),
        "delta_roi_psnr_refined_minus_sp": float((ref_roi_psnr - sp_roi_psnr).mean().cpu()),
        "sp_roi_grad_mae": float(sp_roi_grad_mae.mean().cpu()),
        "refined_roi_grad_mae": float(ref_roi_grad_mae.mean().cpu()),
        "delta_roi_grad_mae_sp_minus_refined": float((sp_roi_grad_mae - ref_roi_grad_mae).mean().cpu()),
        "sp_roi_lap_mae": float(sp_roi_lap_mae.mean().cpu()),
        "refined_roi_lap_mae": float(ref_roi_lap_mae.mean().cpu()),
        "delta_roi_lap_mae_sp_minus_refined": float((sp_roi_lap_mae - ref_roi_lap_mae).mean().cpu()),
        "sp_roi_hf_mae": float(sp_roi_hf_mae.mean().cpu()),
        "refined_roi_hf_mae": float(ref_roi_hf_mae.mean().cpu()),
        "delta_roi_hf_mae_sp_minus_refined": float((sp_roi_hf_mae - ref_roi_hf_mae).mean().cpu()),
        "winner_mae": f"refined {int((ref_mae < sp_mae).sum().cpu())}/{n}",
        "winner_roi_mae": f"refined {int((ref_roi_mae < sp_roi_mae).sum().cpu())}/{n}",
        "winner_roi_grad_mae": f"refined {int((ref_roi_grad_mae < sp_roi_grad_mae).sum().cpu())}/{n}",
        "winner_roi_hf_mae": f"refined {int((ref_roi_hf_mae < sp_roi_hf_mae).sum().cpu())}/{n}",
    }
    rows.append(mean_row)

    fieldnames = list(rows[0].keys())
    write_header = not metrics_csv.exists()
    with metrics_csv.open("a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if write_header:
            writer.writeheader()
        writer.writerows(rows)

    summary = (
        f"step={step_or_epoch}\n"
        f"mean SP ROI MAE      = {mean_row['sp_roi_mae']:.6f}\n"
        f"mean Refined ROI MAE = {mean_row['refined_roi_mae']:.6f}\n"
        f"mean ΔROI_MAE(SP-Refined) = {mean_row['delta_roi_mae_sp_minus_refined']:.6f}  # positive means refined is better\n"
        f"mean SP ROI GradMAE      = {mean_row['sp_roi_grad_mae']:.6f}\n"
        f"mean Refined ROI GradMAE = {mean_row['refined_roi_grad_mae']:.6f}\n"
        f"mean ΔROI_GradMAE(SP-Refined) = {mean_row['delta_roi_grad_mae_sp_minus_refined']:.6f}  # positive means refined is better\n"
        f"mean SP ROI HFMAE      = {mean_row['sp_roi_hf_mae']:.6f}\n"
        f"mean Refined ROI HFMAE = {mean_row['refined_roi_hf_mae']:.6f}\n"
        f"mean ΔROI_HFMAE(SP-Refined) = {mean_row['delta_roi_hf_mae_sp_minus_refined']:.6f}  # positive means refined is better\n"
        f"mean SP ROI PSNR      = {mean_row['sp_roi_psnr']:.3f}\n"
        f"mean Refined ROI PSNR = {mean_row['refined_roi_psnr']:.3f}\n"
        f"mean ΔROI_PSNR(Refined-SP) = {mean_row['delta_roi_psnr_refined_minus_sp']:.3f}  # positive means refined is better\n"
        f"winner ROI MAE: {mean_row['winner_roi_mae']}\n"
        f"winner ROI GradMAE: {mean_row['winner_roi_grad_mae']}\n"
        f"winner ROI HFMAE: {mean_row['winner_roi_hf_mae']}\n"
    )
    summary_txt.write_text(summary, encoding="utf-8")

    return mean_row


# -----------------------------------------------------------------------------
# Solar-disk crop and ROI detection
# -----------------------------------------------------------------------------
def _bicubic_resample():
    try:
        return Image.Resampling.BICUBIC
    except AttributeError:
        return Image.BICUBIC


def estimate_disk_center_radius_stable(
    pil_img: Image.Image,
    thr_ratio: float = 0.2,
    sat_thr_core: float = 0.18,
) -> Tuple[float, float, float]:
    """Estimate solar disk center/radius in raw image coordinates."""
    rgb = np.array(pil_img.convert("RGB"), dtype=np.float32) / 255.0
    h, w, _ = rgb.shape

    gray = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    cmax = rgb.max(axis=2)
    cmin = rgb.min(axis=2)
    sat = (cmax - cmin) / (cmax + 1e-6)

    maxv = float(gray.max()) if gray.size else 0.0
    if maxv <= 0.0:
        return w / 2.0, h / 2.0, min(h, w) / 2.2

    core_mask = (gray > (thr_ratio * maxv)) & (sat > sat_thr_core)
    ys, xs = np.where(core_mask)

    if ys.size < 50:
        bright_mask = gray > (thr_ratio * maxv)
        ys, xs = np.where(bright_mask)

    if ys.size < 10:
        return w / 2.0, h / 2.0, min(h, w) / 2.2

    cx = float(xs.mean())
    cy = float(ys.mean())

    bottom_cut = int(h * 0.90)
    radius_mask = (gray > (thr_ratio * maxv * 0.8)) & (sat > (sat_thr_core * 0.5))
    radius_mask[bottom_cut:, :] = False
    ys_r, xs_r = np.where(radius_mask)
    if ys_r.size < 10:
        ys_r, xs_r = ys, xs

    dists = np.sqrt((xs_r - cx) ** 2 + (ys_r - cy) ** 2)
    r = float(np.percentile(dists, 99) * 1.02)
    r = min(r, min(h, w) * 0.5)
    return cx, cy, r


def crop_and_normalize_disk(
    pil_img: Image.Image,
    out_size: int,
    flip: bool = False,
    to_normal: bool = True,
    thr_ratio: float = 0.2,
    radius_margin: float = 1.05,
) -> torch.Tensor:
    """Crop solar disk from raw image and resize to out_size x out_size."""
    pil_img = pil_img.convert("RGB")
    cx, cy, r = estimate_disk_center_radius_stable(pil_img, thr_ratio=thr_ratio)

    side = int(np.ceil(2.0 * r * radius_margin))
    half = side // 2
    left = int(round(cx - half))
    top = int(round(cy - half))
    right = left + side
    bottom = top + side

    w, h = pil_img.size
    pad_left = max(0, -left)
    pad_top = max(0, -top)
    pad_right = max(0, right - w)
    pad_bottom = max(0, bottom - h)

    if pad_left or pad_top or pad_right or pad_bottom:
        canvas = Image.new("RGB", (w + pad_left + pad_right, h + pad_top + pad_bottom), (0, 0, 0))
        canvas.paste(pil_img, (pad_left, pad_top))
        left += pad_left
        right += pad_left
        top += pad_top
        bottom += pad_top
        pil_img = canvas

    crop = pil_img.crop((left, top, right, bottom))
    if flip:
        crop = ImageOps.mirror(crop)
    crop = crop.resize((out_size, out_size), resample=_bicubic_resample())

    tensor = transforms.ToTensor()(crop)

    # Optional cleanup of bright white text/ticks outside the normalized disk.
    c, ht, wt = tensor.shape
    r_norm = out_size / (2.0 * radius_margin)
    yy = torch.arange(ht, dtype=torch.float32).view(ht, 1)
    xx = torch.arange(wt, dtype=torch.float32).view(1, wt)
    cy_n = (ht - 1) / 2.0
    cx_n = (wt - 1) / 2.0
    dist = torch.sqrt((yy - cy_n) ** 2 + (xx - cx_n) ** 2 + 1e-9)
    outside_disk = dist > (r_norm * 1.05)
    safe_outside = dist > (r_norm * 1.00)

    rch, gch, bch = tensor[0], tensor[1], tensor[2]
    gray = 0.299 * rch + 0.587 * gch + 0.114 * bch
    cmax = torch.maximum(torch.maximum(rch, gch), bch)
    cmin = torch.minimum(torch.minimum(rch, gch), bch)
    sat = (cmax - cmin) / (cmax + 1e-6)

    strict_white = (
        (gray > 0.4)
        & (sat < 0.3)
        & (torch.abs(rch - gch) < 0.15)
        & (torch.abs(rch - bch) < 0.15)
        & (torch.abs(gch - bch) < 0.15)
    )
    loose_white = (
        (gray > 0.30)
        & (sat < 0.40)
        & (torch.abs(rch - gch) < 0.20)
        & (torch.abs(rch - bch) < 0.20)
        & (torch.abs(gch - bch) < 0.20)
    )

    kill_outside = outside_disk & strict_white
    bottom_band = yy > (ht * 0.60)
    bottom_raw = bottom_band & (strict_white | loose_white) & safe_outside
    if bottom_raw.any():
        m = bottom_raw.float().unsqueeze(0).unsqueeze(0)
        kernel = torch.ones((1, 1, 3, 3), dtype=m.dtype)
        dilated = F.conv2d(m, kernel, padding=1)[0, 0] > 0
        bottom_raw = dilated & safe_outside
    kill = kill_outside | bottom_raw
    if kill.any():
        tensor[:, kill] = 0.0

    if to_normal:
        tensor = (tensor - 0.5) * 2.0
        tensor = tensor.clamp(-1.0, 1.0)
    return tensor


def disk_mask_hw(h: int, w: int, radius: float, margin: float = 1.0, device=None) -> torch.Tensor:
    yy, xx = torch.meshgrid(torch.arange(h, device=device), torch.arange(w, device=device), indexing="ij")
    cy = (h - 1) / 2.0
    cx = (w - 1) / 2.0
    r = float(radius) * float(margin)
    return (((yy - cy) ** 2 + (xx - cx) ** 2) <= r ** 2).float()


def sobel_magnitude(gray01: torch.Tensor) -> torch.Tensor:
    x = gray01.unsqueeze(0)
    kx = torch.tensor([[[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]], dtype=x.dtype, device=x.device).unsqueeze(1)
    ky = torch.tensor([[[-1, -2, -1], [0, 0, 0], [1, 2, 1]]], dtype=x.dtype, device=x.device).unsqueeze(1)
    gx = F.conv2d(x, kx, padding=1)
    gy = F.conv2d(x, ky, padding=1)
    return torch.sqrt(gx[0, 0] ** 2 + gy[0, 0] ** 2 + 1e-12)


def local_contrast(gray01: torch.Tensor, kernel_size: int = 9) -> torch.Tensor:
    x = gray01.unsqueeze(0)
    pad = kernel_size // 2
    mean = F.avg_pool2d(x, kernel_size=kernel_size, stride=1, padding=pad)
    return (x - mean).abs()[0, 0]


def normalize_inside(x: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    vals = x[mask]
    if vals.numel() == 0:
        return torch.zeros_like(x)
    lo = vals.min()
    hi = torch.quantile(vals, 0.995)
    return ((x - lo) / (hi - lo + eps)).clamp(0, 1)


def roi_components(
    img: torch.Tensor,
    disk_radius: float,
    detect_margin: float,
    bright_q: float,
    grad_q: float,
    contrast_q: float,
    min_pixels: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    gray = to_gray01(img)
    _, h, w = gray.shape
    disk = disk_mask_hw(h, w, disk_radius, detect_margin, device=gray.device).bool()
    vals = gray[0][disk]
    if vals.numel() < min_pixels:
        return torch.zeros_like(gray), torch.zeros_like(gray)

    grad = sobel_magnitude(gray)
    cont = local_contrast(gray, 9)

    bright_score = normalize_inside(gray[0], disk)
    grad_score = normalize_inside(grad, disk)
    cont_score = normalize_inside(cont, disk)

    bright_mask = (gray[0] >= torch.quantile(vals, bright_q)) & disk

    gvals = grad[disk]
    grad_mask = (grad >= torch.quantile(gvals, grad_q)) & disk if gvals.numel() >= min_pixels else torch.zeros_like(disk)

    cvals = cont[disk]
    cont_mask = (cont >= torch.quantile(cvals, contrast_q)) & disk if cvals.numel() >= min_pixels else torch.zeros_like(disk)

    mask = (bright_mask | grad_mask | cont_mask).float().unsqueeze(0)
    score = (0.45 * bright_score + 0.35 * grad_score + 0.20 * cont_score) * disk.float()
    score = score.unsqueeze(0)
    if mask.sum() < min_pixels:
        return torch.zeros_like(mask), torch.zeros_like(score)
    return mask, score


def build_roi_mask_and_score(
    a_full: torch.Tensor,
    b_full: torch.Tensor,
    sp_full: torch.Tensor,
    roi_source: str,
    disk_radius: float,
    detect_margin: float,
    bright_q: float,
    grad_q: float,
    contrast_q: float,
    min_pixels: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    mask_a, score_a = roi_components(a_full, disk_radius, detect_margin, bright_q, grad_q, contrast_q, min_pixels)
    mask_b, score_b = roi_components(b_full, disk_radius, detect_margin, bright_q, grad_q, contrast_q, min_pixels)
    mask_sp, score_sp = roi_components(sp_full, disk_radius, detect_margin, bright_q, grad_q, contrast_q, min_pixels)

    src = roi_source.lower()
    if src in {"gt", "b", "target"}:
        return mask_b, score_b
    if src in {"a", "source", "aia"}:
        return mask_a, score_a
    if src in {"sp", "coarse"}:
        return mask_sp, score_sp
    # Frozen-compatible default: use only A and SP for ROI selection, matching inference.
    if src in {"a_sp_union", "infer_union"}:
        return (mask_a.bool() | mask_sp.bool()).float(), 0.5 * (score_a + score_sp)
    if src in {"a_sp_intersect", "intersect", "intersection"}:
        return (mask_a.bool() & mask_sp.bool()).float(), 0.5 * (score_a + score_sp)
    if src in {"residual", "res", "error"}:
        diff = (to_gray01(b_full) - to_gray01(sp_full)).abs()[0]
        _, h, w = diff.unsqueeze(0).shape
        disk = disk_mask_hw(h, w, disk_radius, detect_margin, device=diff.device).bool()
        vals = diff[disk]
        if vals.numel() < min_pixels:
            return torch.zeros(1, h, w), torch.zeros(1, h, w)
        thr = torch.quantile(vals, 0.90)
        m = ((diff >= thr) & disk).float().unsqueeze(0)
        s = normalize_inside(diff, disk).unsqueeze(0)
        return m, s

    # Default: union of A/B/SP structural ROIs and residual high-error ROI.
    structural = mask_a.bool() | mask_b.bool() | mask_sp.bool()
    score = (score_a + score_b + score_sp) / 3.0
    if src in {"aligned_union", "union", "union_residual"}:
        diff = (to_gray01(b_full) - to_gray01(sp_full)).abs()[0]
        _, h, w = score.shape
        disk = disk_mask_hw(h, w, disk_radius, detect_margin, device=score.device).bool()
        vals = diff[disk]
        if vals.numel() >= min_pixels:
            thr = torch.quantile(vals, 0.90)
            res_mask = ((diff >= thr) & disk).unsqueeze(0)
            structural = structural | res_mask
            score = 0.70 * score + 0.30 * normalize_inside(diff, disk).unsqueeze(0)
        return structural.float(), score

    raise ValueError(f"Unknown roi_source: {roi_source}")


def dilate_mask(mask: torch.Tensor, kernel_size: int) -> torch.Tensor:
    if kernel_size <= 1:
        return mask
    x = mask.unsqueeze(0).float()
    out = F.max_pool2d(x, kernel_size=kernel_size, stride=1, padding=kernel_size // 2)
    return out[0]


def soft_mask(mask: torch.Tensor, smooth_times: int = 2) -> torch.Tensor:
    x = mask.unsqueeze(0).float()
    for _ in range(smooth_times):
        x = F.avg_pool2d(x, kernel_size=5, stride=1, padding=2)
    return x[0].clamp(0, 1)


def choose_center(
    mask: torch.Tensor,
    score: torch.Tensor,
    patch_size: int,
    disk_radius: float,
    center_margin: float,
    kth: Optional[int] = None,
    min_pixels: int = 10,
) -> Tuple[int, int]:
    _, h, w = mask.shape
    center_disk = disk_mask_hw(h, w, disk_radius, center_margin, device=mask.device).bool()
    candidate = (mask[0] > 0.5) & center_disk

    if kth is None:
        coords = torch.nonzero(candidate, as_tuple=False)
        if coords.numel() > 0:
            weights = score[0][candidate].float().clamp(min=1e-6)
            if weights.numel() == coords.shape[0] and float(weights.sum().item()) > 0:
                idx = torch.multinomial(weights / weights.sum(), 1).item()
            else:
                idx = random.randint(0, coords.shape[0] - 1)
            cy, cx = coords[idx].tolist()
            return int(cy), int(cx)
    else:
        work = mask[0].float() * score[0].float() * center_disk.float()
        if int((work > 0).sum().item()) >= min_pixels:
            suppress_radius = max(patch_size // 2, 8)
            cy, cx = h // 2, w // 2
            for _ in range(kth + 1):
                if float(work.max().item()) <= 0:
                    break
                flat = int(work.argmax().item())
                cy, cx = flat // w, flat % w
                y0, y1 = max(0, cy - suppress_radius), min(h, cy + suppress_radius + 1)
                x0, x1 = max(0, cx - suppress_radius), min(w, cx + suppress_radius + 1)
                work[y0:y1, x0:x1] = 0.0
            half = patch_size // 2
            return int(max(half, min(h - half - 1, cy))), int(max(half, min(w - half - 1, cx)))

    coords = torch.nonzero(center_disk, as_tuple=False)
    if coords.numel() > 0:
        cy, cx = coords[random.randint(0, coords.shape[0] - 1)].tolist()
        return int(cy), int(cx)
    return h // 2, w // 2


def crop_patch(x: torch.Tensor, cy: int, cx: int, patch_size: int) -> torch.Tensor:
    c, h, w = x.shape
    half = patch_size // 2
    cy = int(max(half, min(h - half - 1, int(cy))))
    cx = int(max(half, min(w - half - 1, int(cx))))
    y0 = cy - half
    x0 = cx - half
    return x[:, y0 : y0 + patch_size, x0 : x0 + patch_size]


def build_coord_maps(h: int, w: int, disk_radius: float, dtype=torch.float32) -> Tuple[torch.Tensor, torch.Tensor]:
    yy, xx = torch.meshgrid(torch.arange(h, dtype=dtype), torch.arange(w, dtype=dtype), indexing="ij")
    cy = (h - 1) / 2.0
    cx = (w - 1) / 2.0
    coord_x = (xx - cx) / (disk_radius + 1e-6)
    coord_y = (yy - cy) / (disk_radius + 1e-6)
    return coord_x.unsqueeze(0), coord_y.unsqueeze(0)


# -----------------------------------------------------------------------------
# Dataset
# -----------------------------------------------------------------------------
class SolarROIResidualDataset(Dataset):
    def __init__(
        self,
        triplets: Sequence[Tuple[Path, Path, Path, str]],
        patch_size: int = 96,
        full_image_size: int = 256,
        patches_per_image: int = 4,
        to_normal: bool = True,
        flip: bool = True,
        train: bool = True,
        roi_source: str = "a_sp_union",
        bright_q: float = 0.95,
        grad_q: float = 0.97,
        contrast_q: float = 0.97,
        roi_dilate_kernel: int = 5,
        roi_min_pixels: int = 10,
        roi_detect_disk_margin: float = 0.90,
        roi_center_disk_margin: float = 0.55,
        radius_margin: float = 1.05,
        thr_ratio: float = 0.2,
        mask_smooth_times: int = 2,
        use_coord_channels: bool = False,
    ):
        self.triplets = list(triplets)
        self.patch_size = int(patch_size)
        self.full_image_size = int(full_image_size)
        self.patches_per_image = int(patches_per_image)
        self.to_normal = bool(to_normal)
        self.flip_enabled = bool(flip and train)
        self.train = train
        self.roi_source = roi_source
        self.bright_q = float(bright_q)
        self.grad_q = float(grad_q)
        self.contrast_q = float(contrast_q)
        self.roi_dilate_kernel = int(roi_dilate_kernel)
        self.roi_min_pixels = int(roi_min_pixels)
        self.roi_detect_disk_margin = float(roi_detect_disk_margin)
        self.roi_center_disk_margin = float(roi_center_disk_margin)
        self.radius_margin = float(radius_margin)
        self.thr_ratio = float(thr_ratio)
        self.mask_smooth_times = int(mask_smooth_times)
        self.use_coord_channels = bool(use_coord_channels)
        self.disk_radius = self.full_image_size / (2.0 * self.radius_margin)
        self.base_len = len(self.triplets) * self.patches_per_image

    def __len__(self) -> int:
        return self.base_len * 2 if self.flip_enabled else self.base_len

    def _load_full(self, path: Path, do_flip: bool) -> torch.Tensor:
        # Frozen-version loader: do NOT crop, resize, clean, or re-estimate the solar disk.
        return read_frozen_image_as_normalized_tensor(
            path,
            expected_size=self.full_image_size,
            flip=do_flip,
            to_normal=self.to_normal,
        )

    def __getitem__(self, index: int):
        do_flip = False
        real_index = index
        if self.flip_enabled and index >= self.base_len:
            real_index = index - self.base_len
            do_flip = True

        img_i = real_index // self.patches_per_image
        patch_i = real_index % self.patches_per_image
        a_path, b_path, sp_path, stem = self.triplets[img_i]

        a_full = self._load_full(a_path, do_flip)
        b_full = self._load_full(b_path, do_flip)
        sp_full = self._load_full(sp_path, do_flip)

        roi_mask, roi_score = build_roi_mask_and_score(
            a_full,
            b_full,
            sp_full,
            roi_source=self.roi_source,
            disk_radius=self.disk_radius,
            detect_margin=self.roi_detect_disk_margin,
            bright_q=self.bright_q,
            grad_q=self.grad_q,
            contrast_q=self.contrast_q,
            min_pixels=self.roi_min_pixels,
        )
        roi_mask = dilate_mask(roi_mask, self.roi_dilate_kernel)

        cy, cx = choose_center(
            roi_mask,
            roi_score,
            self.patch_size,
            self.disk_radius,
            self.roi_center_disk_margin,
            kth=None if self.train else patch_i,
            min_pixels=self.roi_min_pixels,
        )

        a_patch = crop_patch(a_full, cy, cx, self.patch_size)
        b_patch = crop_patch(b_full, cy, cx, self.patch_size)
        sp_patch = crop_patch(sp_full, cy, cx, self.patch_size)
        m_patch = crop_patch(roi_mask, cy, cx, self.patch_size)
        m_soft = soft_mask(m_patch, self.mask_smooth_times)

        condition_parts = [a_patch, sp_patch, m_soft]
        if self.use_coord_channels:
            coord_x_full, coord_y_full = build_coord_maps(self.full_image_size, self.full_image_size, self.disk_radius)
            condition_parts.append(crop_patch(coord_x_full, cy, cx, self.patch_size))
            condition_parts.append(crop_patch(coord_y_full, cy, cx, self.patch_size))

        condition = torch.cat(condition_parts, dim=0)
        residual = (b_patch - sp_patch).clamp(-2.0, 2.0)
        refined_gt = b_patch

        name = f"{stem}_roi{patch_i}_y{cy}_x{cx}"
        return {
            "condition": condition,
            "residual": residual,
            "aia": a_patch,
            "sp": sp_patch,
            "gt": refined_gt,
            "mask": m_soft,
            "name": name,
        }


# -----------------------------------------------------------------------------
# Losses and validation
# -----------------------------------------------------------------------------
def charbonnier_loss(x: torch.Tensor, y: torch.Tensor, eps: float = 1e-3, weight: Optional[torch.Tensor] = None) -> torch.Tensor:
    loss = torch.sqrt((x - y) ** 2 + eps**2)
    if weight is not None:
        loss = loss * weight
        return loss.sum() / (weight.sum() * x.shape[1] + 1e-6)
    return loss.mean()


def gradient_xy(x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    gx = x[:, :, :, 1:] - x[:, :, :, :-1]
    gy = x[:, :, 1:, :] - x[:, :, :-1, :]
    return gx, gy


def gradient_loss(pred: torch.Tensor, target: torch.Tensor, weight: Optional[torch.Tensor] = None) -> torch.Tensor:
    px, py = gradient_xy(pred)
    tx, ty = gradient_xy(target)
    if weight is None:
        return (px - tx).abs().mean() + (py - ty).abs().mean()
    wx = weight[:, :, :, 1:]
    wy = weight[:, :, 1:, :]
    lx = ((px - tx).abs() * wx).sum() / (wx.sum() * pred.shape[1] + 1e-6)
    ly = ((py - ty).abs() * wy).sum() / (wy.sum() * pred.shape[1] + 1e-6)
    return lx + ly


def gray_for_loss(x: torch.Tensor) -> torch.Tensor:
    """Convert RGB/gray tensor [B,C,H,W] in [-1,1] to grayscale [B,1,H,W]."""
    if x.shape[1] >= 3:
        return 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
    return x.mean(dim=1, keepdim=True)


def sobel_magnitude_loss(pred: torch.Tensor, target: torch.Tensor, weight: Optional[torch.Tensor] = None) -> torch.Tensor:
    """
    Sobel-gradient-magnitude loss.

    This is intentionally aligned with the ROI GradMAE preview metric, which also
    compares Sobel magnitude maps. It encourages edge/gradient responses of the
    refined patch to remain close to GT.
    """
    pred_g = gray_for_loss(pred.float())
    target_g = gray_for_loss(target.float())

    kx = torch.tensor(
        [[[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]],
        dtype=pred_g.dtype,
        device=pred_g.device,
    ).unsqueeze(1)
    ky = torch.tensor(
        [[[-1, -2, -1], [0, 0, 0], [1, 2, 1]]],
        dtype=pred_g.dtype,
        device=pred_g.device,
    ).unsqueeze(1)

    pred_x = F.conv2d(pred_g, kx, padding=1)
    pred_y = F.conv2d(pred_g, ky, padding=1)
    target_x = F.conv2d(target_g, kx, padding=1)
    target_y = F.conv2d(target_g, ky, padding=1)

    pred_mag = torch.sqrt(pred_x.pow(2) + pred_y.pow(2) + 1e-12)
    target_mag = torch.sqrt(target_x.pow(2) + target_y.pow(2) + 1e-12)
    loss = (pred_mag - target_mag).abs()

    if weight is not None:
        # Sobel magnitude is single-channel, so use a single-channel spatial weight.
        w = weight[:, :1].float()
        return (loss * w).sum() / (w.sum() + 1e-6)
    return loss.mean()


def residual_magnitude_loss(pred_residual: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """
    Penalize overly large ROI residual corrections.

    The refiner should behave as a local correction to SP-BBDM rather than a
    second full generator. This term helps reduce over-aggressive local changes,
    which can hurt LPIPS and gradient consistency.
    """
    w = mask.clamp(0, 1)
    return (pred_residual.abs() * w).sum() / (w.sum() * pred_residual.shape[1] + 1e-6)


def build_lpips_fn(device: torch.device, net: str = "alex"):
    """Create a frozen LPIPS loss network only when lambda_lpips > 0."""
    try:
        import lpips  # type: ignore
    except Exception as exc:
        raise ImportError(
            "lambda_lpips > 0 requires the lpips package. Install it with: pip install lpips"
        ) from exc

    loss_fn = lpips.LPIPS(net=net).to(device)
    loss_fn.eval()
    for p in loss_fn.parameters():
        p.requires_grad_(False)
    return loss_fn


def compute_loss(
    pred_residual: torch.Tensor,
    batch: Dict[str, torch.Tensor],
    lambda_res: float,
    lambda_refined: float,
    lambda_grad: float,
    mask_boost: float,
    lambda_sobel: float = 0.0,
    lambda_lpips: float = 0.0,
    lambda_res_mag: float = 0.0,
    lpips_fn: Optional[nn.Module] = None,
) -> Tuple[torch.Tensor, Dict[str, float], torch.Tensor]:
    sp = batch["sp"]
    gt = batch["gt"]
    mask = batch["mask"]
    target_res = batch["residual"]

    refined = (sp + mask * pred_residual).clamp(-1.0, 1.0)
    roi_weight = 1.0 + float(mask_boost) * mask

    loss_res = charbonnier_loss(pred_residual, target_res, weight=roi_weight)
    loss_ref = charbonnier_loss(refined, gt, weight=roi_weight)
    loss_grad = gradient_loss(refined, gt, weight=roi_weight)

    if lambda_sobel > 0:
        loss_sobel = sobel_magnitude_loss(refined, gt, weight=roi_weight)
    else:
        loss_sobel = refined.new_tensor(0.0)

    if lambda_lpips > 0:
        if lpips_fn is None:
            raise RuntimeError("lambda_lpips > 0 but lpips_fn is None.")
        # LPIPS expects images in [-1, 1]. Use float32 for numerical stability,
        # especially when AMP is enabled.
        loss_lpips = lpips_fn(refined.float().clamp(-1, 1), gt.float().clamp(-1, 1)).mean()
    else:
        loss_lpips = refined.new_tensor(0.0)

    if lambda_res_mag > 0:
        loss_res_mag = residual_magnitude_loss(pred_residual, mask)
    else:
        loss_res_mag = refined.new_tensor(0.0)

    loss = (
        lambda_res * loss_res
        + lambda_refined * loss_ref
        + lambda_grad * loss_grad
        + lambda_sobel * loss_sobel
        + lambda_lpips * loss_lpips
        + lambda_res_mag * loss_res_mag
    )
    info = {
        "loss_res": float(loss_res.detach().cpu()),
        "loss_refined": float(loss_ref.detach().cpu()),
        "loss_grad": float(loss_grad.detach().cpu()),
        "loss_sobel": float(loss_sobel.detach().cpu()),
        "loss_lpips": float(loss_lpips.detach().cpu()),
        "loss_res_mag": float(loss_res_mag.detach().cpu()),
        "loss_total": float(loss.detach().cpu()),
    }
    return loss, info, refined




def _load_preview_font(size: int = 16):
    """Load a font that supports symbols such as Δ when available."""
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    ]
    for fp in candidates:
        try:
            if os.path.exists(fp):
                return ImageFont.truetype(fp, size=size)
        except Exception:
            pass
    return ImageFont.load_default()


def _tensor_grid_to_pil(tensor: torch.Tensor, nrow: int) -> Image.Image:
    """Convert a [N,C,H,W] tensor in [0,1] into a PIL grid image."""
    grid = make_grid(tensor.detach().cpu().clamp(0, 1), nrow=nrow, padding=2)
    arr = (grid.permute(1, 2, 0).numpy() * 255.0).round().astype(np.uint8)
    return Image.fromarray(arr)


def _wrap_caption_lines(lines: Sequence[str], font: ImageFont.ImageFont, max_width: int, draw: ImageDraw.ImageDraw) -> List[str]:
    """Wrap long caption lines so they fit under the preview image."""
    wrapped: List[str] = []
    for line in lines:
        # Estimate width-aware wrapping. Start from a character count, then refine.
        avg_char_w = max(draw.textlength("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", font=font) / 62.0, 5.0)
        max_chars = max(35, int(max_width / avg_char_w))
        chunks = textwrap.wrap(line, width=max_chars, break_long_words=False, replace_whitespace=False)
        if not chunks:
            wrapped.append(line)
            continue
        # If a chunk is still too wide, reduce width until it fits reasonably.
        for chunk in chunks:
            if draw.textlength(chunk, font=font) <= max_width:
                wrapped.append(chunk)
            else:
                narrower = max(25, int(max_chars * 0.82))
                wrapped.extend(textwrap.wrap(chunk, width=narrower, break_long_words=False, replace_whitespace=False))
    return wrapped


def save_grid_with_caption(tensor: torch.Tensor, path: Path, nrow: int, caption_lines: Optional[Sequence[str]] = None) -> None:
    """Save a preview grid and append a compact readable text panel below it."""
    img = _tensor_grid_to_pil(tensor, nrow=nrow)
    if not caption_lines:
        img.save(path)
        return

    # Smaller fonts prevent captions from being clipped under narrow preview grids.
    font = _load_preview_font(size=11)
    small_font = _load_preview_font(size=10)

    pad_x = 8
    pad_y = 6
    line_gap = 3
    max_text_width = max(10, img.width - 2 * pad_x)

    dummy = Image.new("RGB", (10, 10), (255, 255, 255))
    draw_dummy = ImageDraw.Draw(dummy)
    caption_lines = _wrap_caption_lines(caption_lines, small_font, max_text_width, draw_dummy)

    line_heights = []
    for line in caption_lines:
        try:
            bbox = draw_dummy.textbbox((0, 0), line, font=small_font)
            h = bbox[3] - bbox[1]
        except Exception:
            h = draw_dummy.textsize(line, font=small_font)[1]
        line_heights.append(max(h, 11))

    panel_h = pad_y * 2 + sum(line_heights) + line_gap * max(0, len(caption_lines) - 1)
    out = Image.new("RGB", (img.width, img.height + panel_h), (255, 255, 255))
    out.paste(img, (0, 0))
    draw = ImageDraw.Draw(out)

    y = img.height + pad_y
    for i, line in enumerate(caption_lines):
        draw.text((pad_x, y), line, fill=(0, 0, 0), font=font if i == 0 else small_font)
        y += line_heights[i] + line_gap
    out.save(path)


def build_preview_caption(step_or_epoch: int, mean_metrics: Dict[str, float]) -> List[str]:
    """Build compact caption lines written below each preview image."""
    line1 = (
        f"step={int(step_or_epoch)} | ROI_MAE: SP={mean_metrics['sp_roi_mae']:.5f}, "
        f"Ref={mean_metrics['refined_roi_mae']:.5f}, "
        f"Δ={mean_metrics['delta_roi_mae_sp_minus_refined']:.5f}, "
        f"winner={mean_metrics['winner_roi_mae']}"
    )
    line2 = (
        f"Detail ROI_GradMAE: SP={mean_metrics['sp_roi_grad_mae']:.5f}, "
        f"Ref={mean_metrics['refined_roi_grad_mae']:.5f}, "
        f"Δ={mean_metrics['delta_roi_grad_mae_sp_minus_refined']:.5f}, "
        f"winner={mean_metrics['winner_roi_grad_mae']}"
    )
    line3 = (
        f"Texture ROI_HFMAE: SP={mean_metrics['sp_roi_hf_mae']:.5f}, "
        f"Ref={mean_metrics['refined_roi_hf_mae']:.5f}, "
        f"Δ={mean_metrics['delta_roi_hf_mae_sp_minus_refined']:.5f}, "
        f"winner={mean_metrics['winner_roi_hf_mae']}"
    )
    line4 = (
        f"ROI_PSNR: SP={mean_metrics['sp_roi_psnr']:.2f}, "
        f"Ref={mean_metrics['refined_roi_psnr']:.2f}, "
        f"Δ={mean_metrics['delta_roi_psnr_refined_minus_sp']:.2f} dB. "
        f"Positive Δ means Refined is better."
    )
    return [line1, line2, line3, line4]


@torch.no_grad()
def save_preview(model: nn.Module, loader: DataLoader, out_dir: Path, device: torch.device, step_or_epoch: int, max_items: int = 4) -> None:
    model.eval()
    out_dir.mkdir(parents=True, exist_ok=True)
    batch = next(iter(loader))
    condition = batch["condition"].to(device)
    sp = batch["sp"].to(device)
    gt = batch["gt"].to(device)
    mask = batch["mask"].to(device)
    aia = batch["aia"].to(device)
    names = batch.get("name", [f"sample_{i}" for i in range(condition.shape[0])])

    n = min(max_items, condition.shape[0])
    condition = condition[:n]
    sp = sp[:n]
    gt = gt[:n]
    mask = mask[:n]
    aia = aia[:n]
    names = list(names[:n]) if isinstance(names, (list, tuple)) else [str(names)] * n

    pred_res = model(condition)
    refined = (sp + mask * pred_res).clamp(-1, 1)
    target_res = (gt - sp).clamp(-2, 2)

    # Main preview rows:
    # row 1: AIA input
    # row 2: SP-BBDM coarse H-alpha
    # row 3: ROI mask
    # row 4: NAFNet refined H-alpha
    # row 5: GT H-alpha
    # Quantitative preview comparison:
    # Compare SP vs GT and refined vs GT. CSV is appended at every preview step.
    mean_metrics = append_preview_metrics(out_dir, step_or_epoch, names, sp, refined, gt, mask)
    caption_lines = build_preview_caption(step_or_epoch, mean_metrics)

    rows = []
    rows.extend([tensor_to_save(aia), tensor_to_save(sp), mask_to_save(mask), tensor_to_save(refined), tensor_to_save(gt)])
    grid = torch.cat(rows, dim=0)
    save_grid_with_caption(grid, out_dir / f"preview_{step_or_epoch:06d}.png", nrow=n, caption_lines=caption_lines)

    # Residual visualization:
    # row 1: GT residual = GT - SP
    # row 2: predicted residual
    res_grid = torch.cat([
        tensor_to_save(target_res.clamp(-1, 1)),
        tensor_to_save(pred_res.clamp(-1, 1)),
    ], dim=0)
    res_caption = [
        f"step={int(step_or_epoch)}  residual preview: row1=GT residual (GT-SP), row2=predicted residual",
        caption_lines[0],
    ]
    save_grid_with_caption(res_grid, out_dir / f"residual_{step_or_epoch:06d}.png", nrow=n, caption_lines=res_caption)

    print(
        f"[Preview metrics] step={step_or_epoch} "
        f"ROI_MAE SP={mean_metrics['sp_roi_mae']:.5f} "
        f"Refined={mean_metrics['refined_roi_mae']:.5f} "
        f"Δ={mean_metrics['delta_roi_mae_sp_minus_refined']:.5f} "
        f"winner={mean_metrics['winner_roi_mae']} "
        f"GradΔ={mean_metrics.get('delta_roi_grad_mae_sp_minus_refined', 0.0):.5f}"
    )


@torch.no_grad()
def validate(model: nn.Module, loader: DataLoader, device: torch.device, args, lpips_fn: Optional[nn.Module] = None) -> Dict[str, float]:
    """Return validation loss and refined-image PSNR.

    This function intentionally records only the PSNR of the REF-refined output
    against GT, because it is used for monitoring the frozen REF training curve.
    """
    model.eval()
    total = {
        "loss_total": 0.0,
        "loss_res": 0.0,
        "loss_refined": 0.0,
        "loss_grad": 0.0,
        "loss_sobel": 0.0,
        "loss_lpips": 0.0,
        "loss_res_mag": 0.0,
    }
    batch_count = 0
    psnr_sum = 0.0
    image_count = 0

    for batch in loader:
        for key in ["condition", "sp", "gt", "mask", "residual"]:
            batch[key] = batch[key].to(device, non_blocking=True)

        pred_res = model(batch["condition"])
        _, info, refined = compute_loss(
            pred_res,
            batch,
            args.lambda_res,
            args.lambda_refined,
            args.lambda_grad,
            args.mask_boost,
            args.lambda_sobel,
            args.lambda_lpips,
            args.lambda_res_mag,
            lpips_fn,
        )

        for k in total:
            total[k] += info[k]
        batch_count += 1

        refined_psnr = psnr_from_mse(mse_per_image(refined, batch["gt"], None))
        psnr_sum += float(refined_psnr.sum().detach().cpu())
        image_count += int(refined_psnr.numel())

    out = {k: v / max(1, batch_count) for k, v in total.items()}
    out["refined_psnr"] = psnr_sum / max(1, image_count)
    return out


def write_loss_csv(path: Path, rows: List[Dict[str, float]]) -> None:
    if not rows:
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def append_csv_row(path: Path, row: Dict[str, float]) -> None:
    """Append one row to a CSV file, creating the header when needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists()
    with path.open("a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def _read_csv_named(csv_path: Path):
    if not csv_path.exists():
        return None
    data = np.genfromtxt(csv_path, delimiter=",", names=True)
    if data.size == 0:
        return None
    # np.genfromtxt returns a scalar structured array when there is only one row.
    return np.atleast_1d(data)


def plot_losses(csv_path: Path, out_path: Path) -> None:
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return
    data = _read_csv_named(csv_path)
    if data is None:
        return
    plt.figure(figsize=(8, 5))
    if "train_loss_total" in data.dtype.names:
        plt.plot(data["step"], data["train_loss_total"], label="train")
    if "val_loss_total" in data.dtype.names:
        val = data["val_loss_total"]
        step = data["step"]
        keep = ~np.isnan(val)
        if keep.any():
            plt.plot(step[keep], val[keep], label="val")
    plt.xlabel("step")
    plt.ylabel("loss")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_step_metric_curves(csv_path: Path, out_dir: Path) -> None:
    """Plot the three requested step-level curves: train loss, val loss, val PSNR."""
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return
    data = _read_csv_named(csv_path)
    if data is None:
        return

    step = data["step"]

    if "train_loss" in data.dtype.names:
        plt.figure(figsize=(8, 5))
        plt.plot(step, data["train_loss"], label="train loss")
        plt.xlabel("step")
        plt.ylabel("train loss")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / "train_loss_step_curve.png", dpi=150)
        plt.close()

    if "val_loss" in data.dtype.names:
        val_loss = data["val_loss"]
        keep = ~np.isnan(val_loss)
        if keep.any():
            plt.figure(figsize=(8, 5))
            plt.plot(step[keep], val_loss[keep], label="val loss")
            plt.xlabel("step")
            plt.ylabel("val loss")
            plt.legend()
            plt.tight_layout()
            plt.savefig(out_dir / "val_loss_step_curve.png", dpi=150)
            plt.close()

    if "val_refined_psnr" in data.dtype.names:
        val_psnr = data["val_refined_psnr"]
        keep = ~np.isnan(val_psnr)
        if keep.any():
            plt.figure(figsize=(8, 5))
            plt.plot(step[keep], val_psnr[keep], label="val refined PSNR")
            plt.xlabel("step")
            plt.ylabel("val refined PSNR (dB)")
            plt.legend()
            plt.tight_layout()
            plt.savefig(out_dir / "val_refined_psnr_step_curve.png", dpi=150)
            plt.close()


# -----------------------------------------------------------------------------
# Main training
# -----------------------------------------------------------------------------
def build_loaders(args):
    train_triplets = match_triplets(args.train_a_dir, args.train_b_dir, args.train_sp_dir, args.match_mode)
    train_dataset = SolarROIResidualDataset(
        train_triplets,
        patch_size=args.patch_size,
        full_image_size=args.full_image_size,
        patches_per_image=args.patches_per_image,
        to_normal=True,
        flip=not args.no_flip,
        train=True,
        roi_source=args.roi_source,
        bright_q=args.roi_bright_quantile,
        grad_q=args.roi_grad_quantile,
        contrast_q=args.roi_contrast_quantile,
        roi_dilate_kernel=args.roi_dilate_kernel,
        roi_min_pixels=args.roi_min_pixels,
        roi_detect_disk_margin=args.roi_detect_disk_margin,
        roi_center_disk_margin=args.roi_center_disk_margin,
        radius_margin=args.radius_margin,
        thr_ratio=args.disk_thr_ratio,
        mask_smooth_times=args.mask_smooth_times,
        use_coord_channels=args.use_coord_channels,
    )

    val_loader = None
    if args.val_a_dir and args.val_b_dir and args.val_sp_dir:
        val_triplets = match_triplets(args.val_a_dir, args.val_b_dir, args.val_sp_dir, args.match_mode)
        val_dataset = SolarROIResidualDataset(
            val_triplets,
            patch_size=args.patch_size,
            full_image_size=args.full_image_size,
            patches_per_image=min(args.patches_per_image, 4),
            to_normal=True,
            flip=False,
            train=False,
            roi_source=args.roi_source,
            bright_q=args.roi_bright_quantile,
            grad_q=args.roi_grad_quantile,
            contrast_q=args.roi_contrast_quantile,
            roi_dilate_kernel=args.roi_dilate_kernel,
            roi_min_pixels=args.roi_min_pixels,
            roi_detect_disk_margin=args.roi_detect_disk_margin,
            roi_center_disk_margin=args.roi_center_disk_margin,
            radius_margin=args.radius_margin,
            thr_ratio=args.disk_thr_ratio,
            mask_smooth_times=args.mask_smooth_times,
            use_coord_channels=args.use_coord_channels,
        )
    elif args.val_fraction > 0.0:
        n_val = max(1, int(len(train_dataset) * args.val_fraction))
        n_train = len(train_dataset) - n_val
        train_dataset, val_dataset = random_split(
            train_dataset,
            [n_train, n_val],
            generator=torch.Generator().manual_seed(args.seed),
        )
    else:
        val_dataset = None

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=True,
    )
    if val_dataset is not None:
        val_loader = DataLoader(
            val_dataset,
            batch_size=args.batch_size,
            shuffle=False,
            num_workers=args.num_workers,
            pin_memory=True,
            drop_last=False,
        )
    return train_loader, val_loader


def save_checkpoint(path: Path, model: nn.Module, optimizer: torch.optim.Optimizer, epoch: int, step: int, best_val: float, args) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "epoch": epoch,
            "step": step,
            "best_val": best_val,
            "args": vars(args),
        },
        path,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train frozen-version NAFNet ROI residual refiner for solar images.")

    parser.add_argument("--train_a_dir", required=True)
    parser.add_argument("--train_b_dir", required=True)
    parser.add_argument("--train_sp_dir", required=True)
    parser.add_argument("--val_a_dir", default=None)
    parser.add_argument("--val_b_dir", default=None)
    parser.add_argument("--val_sp_dir", default=None)
    parser.add_argument("--val_fraction", type=float, default=0.0, help="Use part of training dataset as validation if val dirs are not provided.")
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--match_mode", choices=["name", "sorted"], default="name", help="Match frozen A/B/SP by filename stem or sorted order.")

    parser.add_argument("--patch_size", type=int, default=96)
    parser.add_argument("--full_image_size", type=int, default=256)
    parser.add_argument("--patches_per_image", type=int, default=4)
    parser.add_argument("--roi_source", type=str, default="a_sp_union", choices=["a_sp_union", "a_sp_intersect", "aligned_union", "union", "union_residual", "gt", "a", "source", "aia", "sp", "coarse", "residual"], help="For frozen consistency, prefer a_sp_union, which uses only A and SP for ROI selection.")
    parser.add_argument("--roi_bright_quantile", type=float, default=0.95)
    parser.add_argument("--roi_grad_quantile", type=float, default=0.97)
    parser.add_argument("--roi_contrast_quantile", type=float, default=0.97)
    parser.add_argument("--roi_dilate_kernel", type=int, default=5)
    parser.add_argument("--roi_min_pixels", type=int, default=10)
    parser.add_argument("--roi_detect_disk_margin", type=float, default=0.90)
    parser.add_argument("--roi_center_disk_margin", type=float, default=0.55)
    parser.add_argument("--radius_margin", type=float, default=1.05)
    parser.add_argument("--disk_thr_ratio", type=float, default=0.2)
    parser.add_argument("--mask_smooth_times", type=int, default=2)
    parser.add_argument("--use_coord_channels", action="store_true")
    parser.add_argument("--no_flip", action="store_true")

    parser.add_argument("--width", type=int, default=32)
    parser.add_argument("--middle_blk_num", type=int, default=4)
    parser.add_argument("--enc_blks", type=str, default="2,2,4")
    parser.add_argument("--dec_blks", type=str, default="2,2,2")
    parser.add_argument("--dropout", type=float, default=0.0)

    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--max_steps", type=int, default=0, help="Maximum number of training steps. Set 0 to disable this limit.")
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--seed", type=int, default=1234)
    parser.add_argument("--amp", action="store_true", help="Use mixed precision.")

    parser.add_argument("--lambda_res", type=float, default=1.0)
    parser.add_argument("--lambda_refined", type=float, default=1.0)
    parser.add_argument("--lambda_grad", type=float, default=0.2)
    parser.add_argument("--lambda_sobel", type=float, default=0.0, help="Sobel magnitude loss weight. Helps align training with ROI GradMAE.")
    parser.add_argument("--lambda_lpips", type=float, default=0.0, help="Small LPIPS loss weight. Requires: pip install lpips.")
    parser.add_argument("--lambda_res_mag", type=float, default=0.0, help="Residual magnitude penalty weight inside ROI mask.")
    parser.add_argument("--lpips_net", type=str, default="alex", choices=["alex", "vgg", "squeeze"], help="Backbone for LPIPS loss.")
    parser.add_argument("--mask_boost", type=float, default=5.0)

    parser.add_argument("--log_interval", type=int, default=50, help="Print running training loss every N steps. Set 0 to disable.")
    parser.add_argument("--metric_step_interval", type=int, default=1000, help="Every N steps, save train loss, val loss, and val refined PSNR to CSV and update curves. Set 0 to disable.")
    parser.add_argument("--preview_step_interval", type=int, default=500, help="Save preview every N training steps. Set 0 to disable step-based previews.")
    parser.add_argument("--save_step_interval", type=int, default=0, help="Save checkpoint every N training steps. Set 0 to disable step-based checkpoints.")
    parser.add_argument("--no_initial_preview", action="store_true", help="Do not save preview_000000.png before training starts.")
    parser.add_argument("--preview_interval", type=int, default=1, help="Save preview every N epochs. Set 0 to disable epoch-based previews.")
    parser.add_argument("--save_interval", type=int, default=10, help="Save checkpoint every N epochs. Set 0 to disable epoch-based checkpoints.")
    parser.add_argument("--resume", type=str, default=None)

    return parser.parse_args()


def main() -> None:
    args = parse_args()
    set_seed(args.seed)

    out_dir = Path(args.out_dir)
    ckpt_dir = out_dir / "checkpoints"
    preview_dir = out_dir / "previews"
    out_dir.mkdir(parents=True, exist_ok=True)
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    preview_dir.mkdir(parents=True, exist_ok=True)

    # Save a copy of the model file for reproducibility if available.
    src_model = Path(__file__).resolve().parent / "nafnet_roi_refiner_standalone.py"
    if src_model.exists():
        shutil.copy2(src_model, out_dir / "nafnet_roi_refiner_standalone.py")

    device = torch.device(args.device if torch.cuda.is_available() or "cuda" not in args.device else "cpu")
    train_loader, val_loader = build_loaders(args)

    enc_blks = tuple(int(x) for x in args.enc_blks.split(",") if x.strip())
    dec_blks = tuple(int(x) for x in args.dec_blks.split(",") if x.strip())
    in_channels = 9 if args.use_coord_channels else 7

    model = NAFNetROIRefiner(
        in_channels=in_channels,
        out_channels=3,
        width=args.width,
        middle_blk_num=args.middle_blk_num,
        enc_blk_nums=enc_blks,
        dec_blk_nums=dec_blks,
        drop_out_rate=args.dropout,
    ).to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp and device.type == "cuda")

    lpips_fn = None
    if args.lambda_lpips > 0:
        lpips_fn = build_lpips_fn(device, net=args.lpips_net)
        print(f"[LPIPS] enabled with net={args.lpips_net}, lambda_lpips={args.lambda_lpips}")

    start_epoch = 0
    global_step = 0
    best_val = float("inf")

    if args.resume:
        ckpt = torch.load(args.resume, map_location="cpu")
        model.load_state_dict(ckpt["model"])
        optimizer.load_state_dict(ckpt["optimizer"])
        start_epoch = int(ckpt.get("epoch", 0)) + 1
        global_step = int(ckpt.get("step", 0))
        best_val = float(ckpt.get("best_val", float("inf")))
        print(f"[Resume] epoch={start_epoch}, step={global_step}, best_val={best_val:.6f}")

    print("=" * 80)
    print(f"Train samples/batches: {len(train_loader.dataset)} / {len(train_loader)}")
    print(f"Val samples/batches:   {len(val_loader.dataset) if val_loader else 0} / {len(val_loader) if val_loader else 0}")
    print(f"Input channels: {in_channels}")
    print(f"Device: {device}")
    print(f"Out dir: {out_dir}")
    print(f"Frozen input: no crop/resize/cleanup is applied; images must already be --full_image_size square.")
    print(f"Match mode: {args.match_mode}")
    print(f"ROI source: {args.roi_source}")
    total_planned_steps = len(train_loader) * max(0, args.epochs - start_epoch)
    if args.max_steps and args.max_steps > 0:
        total_planned_steps = min(total_planned_steps, max(0, args.max_steps - global_step))
    print(f"Total planned steps: {total_planned_steps}")
    print(f"Max steps: {args.max_steps if args.max_steps and args.max_steps > 0 else 'disabled'}")
    print(f"Progress: tqdm bar per epoch; print every {args.log_interval} steps")
    print(f"Metric CSV/curves: every {args.metric_step_interval} steps" if args.metric_step_interval > 0 else "Metric CSV/curves: disabled")
    print(f"Preview: initial + every {args.preview_step_interval} steps + every {args.preview_interval} epochs")
    print(
        "Loss weights: "
        f"res={args.lambda_res}, refined={args.lambda_refined}, grad={args.lambda_grad}, "
        f"sobel={args.lambda_sobel}, lpips={args.lambda_lpips}, res_mag={args.lambda_res_mag}, "
        f"mask_boost={args.mask_boost}"
    )
    print("=" * 80)

    log_rows: List[Dict[str, float]] = []
    csv_path = out_dir / "loss_log.csv"
    metric_step_csv_path = out_dir / "metrics_step_log.csv"
    metric_train_loss_sum = 0.0
    metric_train_loss_count = 0

    # Save an initial preview so you can immediately verify the data pipeline and output layout.
    if not args.no_initial_preview:
        try:
            preview_loader = val_loader if val_loader is not None else train_loader
            save_preview(model, preview_loader, preview_dir, device, 0)
            print(f"[Preview] saved initial preview to: {preview_dir / 'preview_000000.png'}")
        except Exception as exc:
            print(f"[Preview warning] failed to save initial preview: {exc}")

    stop_training = False
    for epoch in range(start_epoch, args.epochs):
        if args.max_steps and args.max_steps > 0 and global_step >= args.max_steps:
            print(f"[Max steps] global_step={global_step} has reached max_steps={args.max_steps}. Stop training.")
            break
        model.train()
        epoch_total = 0.0
        epoch_res = 0.0
        epoch_ref = 0.0
        epoch_grad = 0.0
        epoch_sobel = 0.0
        epoch_lpips = 0.0
        epoch_res_mag = 0.0
        num_batches = 0

        pbar = tqdm(
            train_loader,
            total=len(train_loader),
            desc=f"Epoch {epoch + 1:03d}/{args.epochs:03d}",
            dynamic_ncols=True,
            leave=True,
        )

        for batch_idx, batch in enumerate(pbar, start=1):
            for key in ["condition", "sp", "gt", "mask", "residual"]:
                batch[key] = batch[key].to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=args.amp and device.type == "cuda"):
                pred_res = model(batch["condition"])
                loss, info, _ = compute_loss(
                    pred_res,
                    batch,
                    args.lambda_res,
                    args.lambda_refined,
                    args.lambda_grad,
                    args.mask_boost,
                    args.lambda_sobel,
                    args.lambda_lpips,
                    args.lambda_res_mag,
                    lpips_fn,
                )

            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            scaler.step(optimizer)
            scaler.update()

            global_step += 1
            num_batches += 1
            epoch_total += info["loss_total"]
            epoch_res += info["loss_res"]
            epoch_ref += info["loss_refined"]
            epoch_grad += info["loss_grad"]
            epoch_sobel += info["loss_sobel"]
            epoch_lpips += info["loss_lpips"]
            epoch_res_mag += info["loss_res_mag"]
            metric_train_loss_sum += info["loss_total"]
            metric_train_loss_count += 1

            running_total = epoch_total / max(1, num_batches)
            running_res = epoch_res / max(1, num_batches)
            running_ref = epoch_ref / max(1, num_batches)
            running_grad = epoch_grad / max(1, num_batches)
            running_sobel = epoch_sobel / max(1, num_batches)
            running_lpips = epoch_lpips / max(1, num_batches)
            running_res_mag = epoch_res_mag / max(1, num_batches)
            lr_now = optimizer.param_groups[0]["lr"]
            pbar.set_postfix(
                step=global_step,
                loss=f"{running_total:.4f}",
                res=f"{running_res:.4f}",
                ref=f"{running_ref:.4f}",
                grad=f"{running_grad:.4f}",
                sobel=f"{running_sobel:.4f}",
                lpips=f"{running_lpips:.4f}",
                rmag=f"{running_res_mag:.4f}",
                lr=f"{lr_now:.1e}",
            )

            if args.log_interval > 0 and global_step % args.log_interval == 0:
                pbar.write(
                    f"[Step {global_step}] "
                    f"epoch={epoch + 1}/{args.epochs} batch={batch_idx}/{len(train_loader)} "
                    f"loss={running_total:.6f} res={running_res:.6f} "
                    f"ref={running_ref:.6f} grad={running_grad:.6f} "
                    f"sobel={running_sobel:.6f} lpips={running_lpips:.6f} "
                    f"res_mag={running_res_mag:.6f} lr={lr_now:.2e}"
                )

            if args.metric_step_interval > 0 and global_step % args.metric_step_interval == 0:
                train_loss_for_record = metric_train_loss_sum / max(1, metric_train_loss_count)
                if val_loader is not None:
                    val_info_raw = validate(model, val_loader, device, args, lpips_fn)
                    val_loss_for_record = val_info_raw["loss_total"]
                    val_psnr_for_record = val_info_raw["refined_psnr"]
                else:
                    val_loss_for_record = float("nan")
                    val_psnr_for_record = float("nan")

                metric_row = {
                    "step": global_step,
                    "epoch": epoch + 1,
                    "train_loss": train_loss_for_record,
                    "val_loss": val_loss_for_record,
                    "val_refined_psnr": val_psnr_for_record,
                }
                append_csv_row(metric_step_csv_path, metric_row)
                plot_step_metric_curves(metric_step_csv_path, out_dir)
                pbar.write(
                    f"[Metric Step {global_step}] "
                    f"train_loss={train_loss_for_record:.6f} "
                    f"val_loss={val_loss_for_record:.6f} "
                    f"val_refined_PSNR={val_psnr_for_record:.3f}"
                )
                metric_train_loss_sum = 0.0
                metric_train_loss_count = 0

            if args.preview_step_interval > 0 and global_step % args.preview_step_interval == 0:
                preview_loader = val_loader if val_loader is not None else train_loader
                save_preview(model, preview_loader, preview_dir, device, global_step)
                pbar.write(f"[Preview] step={global_step}, saved to {preview_dir}")

            if args.save_step_interval > 0 and global_step % args.save_step_interval == 0:
                save_checkpoint(ckpt_dir / f"step_{global_step:08d}.pth", model, optimizer, epoch, global_step, best_val, args)
                pbar.write(f"[Checkpoint] step={global_step}, saved to {ckpt_dir}")

            if args.max_steps and args.max_steps > 0 and global_step >= args.max_steps:
                save_checkpoint(ckpt_dir / f"step_{global_step:08d}_maxsteps.pth", model, optimizer, epoch, global_step, best_val, args)
                pbar.write(f"[Max steps] reached global_step={global_step}; saved max-step checkpoint and will stop after this epoch summary.")
                stop_training = True
                break

        train_info = {
            "train_loss_total": epoch_total / max(1, num_batches),
            "train_loss_res": epoch_res / max(1, num_batches),
            "train_loss_refined": epoch_ref / max(1, num_batches),
            "train_loss_grad": epoch_grad / max(1, num_batches),
            "train_loss_sobel": epoch_sobel / max(1, num_batches),
            "train_loss_lpips": epoch_lpips / max(1, num_batches),
            "train_loss_res_mag": epoch_res_mag / max(1, num_batches),
        }

        if val_loader is not None:
            val_info_raw = validate(model, val_loader, device, args, lpips_fn)
            val_info = {
                "val_loss_total": val_info_raw["loss_total"],
                "val_loss_res": val_info_raw["loss_res"],
                "val_loss_refined": val_info_raw["loss_refined"],
                "val_loss_grad": val_info_raw["loss_grad"],
                "val_loss_sobel": val_info_raw["loss_sobel"],
                "val_loss_lpips": val_info_raw["loss_lpips"],
                "val_loss_res_mag": val_info_raw["loss_res_mag"],
                "val_refined_psnr": val_info_raw["refined_psnr"],
            }
        else:
            val_info = {
                "val_loss_total": float("nan"),
                "val_loss_res": float("nan"),
                "val_loss_refined": float("nan"),
                "val_loss_grad": float("nan"),
                "val_loss_sobel": float("nan"),
                "val_loss_lpips": float("nan"),
                "val_loss_res_mag": float("nan"),
                "val_refined_psnr": float("nan"),
            }

        row = {"epoch": epoch, "step": global_step, **train_info, **val_info}
        log_rows.append(row)
        write_loss_csv(csv_path, log_rows)
        plot_losses(csv_path, out_dir / "loss_curve.png")

        msg = (
            f"[Epoch {epoch+1:03d}/{args.epochs}] step={global_step} "
            f"train={train_info['train_loss_total']:.6f} "
        )
        if val_loader is not None:
            msg += f"val={val_info['val_loss_total']:.6f} val_PSNR={val_info['val_refined_psnr']:.3f} "
        msg += (
            f"res={train_info['train_loss_res']:.6f} "
            f"ref={train_info['train_loss_refined']:.6f} "
            f"grad={train_info['train_loss_grad']:.6f} "
            f"sobel={train_info['train_loss_sobel']:.6f} "
            f"lpips={train_info['train_loss_lpips']:.6f} "
            f"res_mag={train_info['train_loss_res_mag']:.6f}"
        )
        print(msg)

        # Epoch-level preview.
        if args.preview_interval > 0 and (epoch + 1) % args.preview_interval == 0:
            preview_loader = val_loader if val_loader is not None else train_loader
            save_preview(model, preview_loader, preview_dir, device, global_step)

        # Best checkpoint.
        current_val = val_info["val_loss_total"] if val_loader is not None else train_info["train_loss_total"]
        if current_val < best_val:
            best_val = current_val
            save_checkpoint(ckpt_dir / "best.pth", model, optimizer, epoch, global_step, best_val, args)

        # Epoch-level checkpoint.
        if args.save_interval > 0 and (epoch + 1) % args.save_interval == 0:
            save_checkpoint(ckpt_dir / f"epoch_{epoch+1:04d}.pth", model, optimizer, epoch, global_step, best_val, args)

        save_checkpoint(ckpt_dir / "last.pth", model, optimizer, epoch, global_step, best_val, args)

        if stop_training:
            print(f"[Max steps] stopped at global_step={global_step}.")
            break

    print(f"Done. Best loss: {best_val:.6f}")


if __name__ == "__main__":
    main()