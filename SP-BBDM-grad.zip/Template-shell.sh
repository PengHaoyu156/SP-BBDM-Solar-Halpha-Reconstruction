#train
#python3 main.py --config configs/solarimage.yaml --train --sample_at_start --save_top --gpu_ids 0 \
#--resume_model results/solarimage/LBBDM-f4-latent0.05/checkpoint/last_model.pth --resume_optim results/solarimage/LBBDM-f4-latent0.05/checkpoint/last_optim_sche.pth

##test
python3 main.py --config configs/solarimage.yaml --sample_to_eval --gpu_ids 0 \
--resume_model results/solarimage/LBBDM-f4-latent0.05/checkpoint/latest_model_43.pth --resume_optim results/solarimage/LBBDM-f4-latent0.05/checkpoint/latest_optim_sche_43.pth


#python3 print_psnr_ssim_lpips_mean_std.py \
#  --pred results/solarimage/LBBDM-f4-latent0.05/sample_to_eval/200 \
#  --gt results/solarimage/LBBDM-f4-latent0.05/sample_to_eval/ground_truth \
#  --device cuda \
#  --csv spbbdm_per_image_metrics.csv




