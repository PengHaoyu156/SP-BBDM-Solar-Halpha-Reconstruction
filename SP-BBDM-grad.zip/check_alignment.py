import os
import torch
from torch.utils.data import DataLoader
import torchvision.utils as vutils

from types import SimpleNamespace
from datasets.custom import CustomAlignedDataset

# --------- 配置区域，你可以按你的情况改 ---------
# 这些值是根据你之前的yaml推的
DATASET_PATH = "/home/a/BBDM-main/solarimage"  # 你的数据根目录
STAGE = "train"                                # 也可以换 "val" / "test"
IMAGE_SIZE = 256                               # yaml里的 data.dataset_config.image_size
TO_NORMAL = True                               # yaml里的 data.to_normal: True
FLIP = False                                   # 这里为了可视化稳定，先关掉随机翻转
OUT_DIR = "./sanity_check_samples"             # 输出的可视化结果会放在这里
NUM_SAMPLES_TO_SAVE = 10                      # 要导出的样本对数量
# ----------------------------------------------


def denorm_if_needed(x):
    """
    x: [C,H,W] tensor
    如果是 [-1,1]，把它还原回 [0,1] 方便保存 + 观察。
    如果本来就在 [0,1]，基本也能工作。
    """
    # clone避免原地动计算图
    x = x.clone()

    # 我们假设训练时 to_normal=True -> 映射到[-1,1]
    # 现在就把它拉回到[0,1]
    x = (x + 1.0) * 0.5
    x = torch.clamp(x, 0.0, 1.0)
    return x


def make_side_by_side(img_cond, img_gt):
    """
    把条件图 (A) 和 目标图 (B) 拼在一起，横向并排。
    输入是 [C,H,W]，输出 [C,H,2W]。
    """
    return torch.cat([img_cond, img_gt], dim=2)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    # 做一个假的 dataset_config 对象，和 CustomAlignedDataset 期望的字段一致
    dataset_config = SimpleNamespace(
        dataset_path=DATASET_PATH,
        image_size=IMAGE_SIZE,
        to_normal=TO_NORMAL,
        flip=FLIP
    )

    # 构建数据集
    dataset = CustomAlignedDataset(dataset_config, stage=STAGE)

    # 用DataLoader只是为了方便批量，但不打乱
    loader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    count = 0
    for batch in loader:
        # batch 结构是:
        #   ((tensor_B, name_B), (tensor_A, name_A))
        # 注意我们之前定义 custom_aligned 时返回是:
        #   ( (gt, gt_name), (cond, cond_name) )
        # 如果你代码里是相反的顺序，就按你实际的来。
        (gt_tensor, gt_name), (cond_tensor, cond_name) = batch

        # shape: [1, C, H, W] -> [C, H, W]
        gt_tensor = gt_tensor[0]
        cond_tensor = cond_tensor[0]

        # 反归一化到[0,1]空间，方便肉眼对比
        gt_vis = denorm_if_needed(gt_tensor)
        cond_vis = denorm_if_needed(cond_tensor)

        # 拼成一张 [C,H,2W]，左=条件波段A，右=目标波段B
        merged = make_side_by_side(cond_vis, gt_vis)

        # 存下来
        out_path = os.path.join(
            OUT_DIR,
            f"sample_{count:03d}__A-{cond_name[0]}__B-{gt_name[0]}.png"
        )
        vutils.save_image(merged, out_path)

        print(f"[saved] {out_path}")

        count += 1
        if count >= NUM_SAMPLES_TO_SAVE:
            break

    print("done. 请打开 sanity_check_samples/ 里这些 PNG 看对齐情况。")


if __name__ == "__main__":
    main()
