import os
from pathlib import Path
import torch
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms

from Register import Registers
from datasets.base import ImagePathDataset
from datasets.utils import (
    get_image_paths_from_dir,
    crop_and_normalize_disk,   # 这个名字保持不变，但实现已经是我们新的稳定版
)


@Registers.datasets.register_with_name('custom_single')
class CustomSingleDataset(Dataset):
    def __init__(self, dataset_config, stage='train'):
        super().__init__()
        self.image_size = (dataset_config.image_size, dataset_config.image_size)
        self.image_paths = get_image_paths_from_dir(
            os.path.join(dataset_config.dataset_path, stage)
        )
        self.flip = dataset_config.flip if stage == 'train' else False
        self.to_normal = dataset_config.to_normal
        self.imgs = ImagePathDataset(
            self.image_paths,
            self.image_size,
            flip=self.flip,
            to_normal=self.to_normal,
        )

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, idx):
        # 返回两份相同 (为了兼容 runner 接口)
        return self.imgs[idx], self.imgs[idx]


@Registers.datasets.register_with_name('custom_aligned')
class CustomAlignedDataset(Dataset):
    def __init__(self, dataset_config, stage='train'):
        super().__init__()
        self.size_out = dataset_config.image_size          # e.g. 256
        self.flip_enabled = dataset_config.flip if stage == 'train' else False
        self.to_normal = dataset_config.to_normal

        base_path = dataset_config.dataset_path
        self.paths_B = get_image_paths_from_dir(
            os.path.join(base_path, f"{stage}/B")
        )  # 目标域 (GT)
        self.paths_A = get_image_paths_from_dir(
            os.path.join(base_path, f"{stage}/A")
        )  # 条件域 (source)

        assert len(self.paths_A) == len(self.paths_B), \
            "A/B 数量不一致，请检查配对"

        self.N = len(self.paths_A)

    def __len__(self):
        if self.flip_enabled:
            return self.N * 2
        return self.N

    def __getitem__(self, index):
        do_flip = False
        real_i = index
        if self.flip_enabled and index >= self.N:
            real_i = index - self.N
            do_flip = True

        path_B = self.paths_B[real_i]
        path_A = self.paths_A[real_i]

        img_B = Image.open(path_B).convert("RGB")
        img_A = Image.open(path_A).convert("RGB")

        # 两个域用完全相同的裁剪-归一化策略
        tensor_B = crop_and_normalize_disk(
            pil_img=img_B,
            out_size=self.size_out,
            flip=do_flip,
            to_normal=self.to_normal,
            thr_ratio=0.2,
            radius_margin=1.05,   # 固定半径比例，确保输出圆盘大小一致
        )
        tensor_A = crop_and_normalize_disk(
            pil_img=img_A,
            out_size=self.size_out,
            flip=do_flip,
            to_normal=self.to_normal,
            thr_ratio=0.2,
            radius_margin=1.05,
        )

        name_B = Path(path_B).stem
        name_A = Path(path_A).stem

        # 按 runner 习惯返回 ((GT, GT_name), (input, input_name))
        return (tensor_B, name_B), (tensor_A, name_A)


@Registers.datasets.register_with_name('custom_colorization_LAB')
class CustomColorizationLABDataset(Dataset):
    # 原样保留，不影响太阳翻译训练
    def __init__(self, dataset_config, stage='train'):
        super().__init__()
        self.image_size = (dataset_config.image_size,
                           dataset_config.image_size)
        self.image_paths = get_image_paths_from_dir(
            os.path.join(dataset_config.dataset_path, stage)
        )
        self.flip = dataset_config.flip if stage == 'train' else False
        self.to_normal = dataset_config.to_normal
        self._length = len(self.image_paths)

    def __len__(self):
        if self.flip:
            return self._length * 2
        return self._length

    def __getitem__(self, index):
        p = False
        if index >= self._length:
            index = index - self._length
            p = True

        import cv2
        import numpy as np

        image = Image.open(self.image_paths[index]).convert('RGB')
        image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2LAB).astype('float')

        image_transform = transforms.Compose([
            transforms.RandomHorizontalFlip(p=float(p)),
            transforms.Resize(self.image_size),
            transforms.ToTensor()
        ])

        l, ab = image[:, :, 0], image[:, :, 1:]
        l = Image.fromarray(l.astype('float'), mode='F')
        ab = Image.fromarray(ab.astype('float'), mode='F')

        l = image_transform(l)    # [1,H,W]
        ab = image_transform(ab)  # [2,H,W]

        # LAB -> [-1,1]
        l = l.div_(50.).add_(-1.)
        ab = ab.div_(110.).add_(-1.)

        x_name = self.image_paths[index]

        return (torch.cat((l, ab), dim=0), x_name), (l.repeat(3, 1, 1), x_name)


@Registers.datasets.register_with_name('custom_inpainting')
class CustomInpaintingDataset(Dataset):
    # 也原样保留
    def __init__(self, dataset_config, stage='train'):
        super().__init__()
        self.image_size = (dataset_config.image_size,
                           dataset_config.image_size)
        self.image_paths = get_image_paths_from_dir(
            os.path.join(dataset_config.dataset_path, stage)
        )
        self.flip = dataset_config.flip if stage == 'train' else False
        self.to_normal = dataset_config.to_normal
        self._length = len(self.image_paths)

    def __len__(self):
        if self.flip:
            return self._length * 2
        return self._length

    def __getitem__(self, index):
        p = False
        if index >= self._length:
            index = index - self._length
            p = True

        image = Image.open(self.image_paths[index]).convert('RGB')

        image_transform = transforms.Compose([
            transforms.RandomHorizontalFlip(p=float(p)),
            transforms.Resize(self.image_size),
            transforms.ToTensor()
        ])

        image = image_transform(image)

        if self.to_normal:
            image = (image - 0.5) * 2.
            image = image.clamp_(-1., 1.)

        mask = torch.zeros_like(image[:1])  # [1,H,W]
        x_name = Path(self.image_paths[index]).stem

        return (image, x_name), (
            torch.cat((image, mask.repeat(3, 1, 1)), dim=0),
            x_name
        )
