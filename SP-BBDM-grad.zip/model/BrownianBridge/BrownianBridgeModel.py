import torch
import torch.nn as nn
import torch.nn.functional as F
from functools import partial
import numpy as np
from tqdm.autonotebook import tqdm

from model.BrownianBridge.base.modules.image_degradation.utils_image import (
    calculate_ssim, calculate_psnr,
)
from model.utils import extract, default
from model.BrownianBridge.base.modules.diffusionmodules.openaimodel import UNetModel


class BrownianBridgeModel(nn.Module):
    def __init__(self, model_config):
        super().__init__()
        self.model_config = model_config
        params = model_config.BB.params

        # schedule
        self.num_timesteps = params.num_timesteps
        self.mt_type = params.mt_type
        self.max_var = params.max_var if params.__contains__("max_var") else 1.0
        self.eta = params.eta if params.__contains__("eta") else 1.0
        self.skip_sample = params.skip_sample
        self.sample_type = params.sample_type
        self.sample_step = params.sample_step
        self.steps = None
        self.register_schedule()

        # loss and objective
        self.loss_type = params.loss_type  # 'l1' | 'l2'
        self.objective = params.objective  # 'grad' | 'noise' | 'ysubx'

        # UNet
        unetp = params.UNetParams
        self.image_size = unetp.image_size
        self.channels = unetp.in_channels
        self.condition_key = unetp.condition_key
        self.denoise_fn = UNetModel(**vars(unetp))

        # ----- 固定梯度一致性损失权重消融实验：无退火 -----
        # 本实验用于回应审稿人关于“固定权重 vs 退火权重”的消融问题。
        # 设置目标：
        #   fixed w_grad = 0.08
        #   no annealing
        #   down = 2
        #   max_pairs = 8
        #
        # 注意：
        #   当前代码中的 SSIM/PSNR 只用于日志监控，不参与反向传播。
        #   因此这里将 w_ssim 设为 0.0，避免日志中的 total loss 被无梯度常数项干扰。
        self.mix_max_w_ssim = 0.0
        self.mix_max_w_grad = 0.05

        # 固定权重实验中不再使用退火阶段。
        # 这里保留变量只是为了避免其他位置可能访问时报错。
        self.mix_stage1_end = 20000
        self.mix_stage2_end = 40000

        # 由 runner 在每次 loss_fn 调用前写入。
        # 固定权重实验中不再用 current_step 计算退火。
        self.current_step = 0

    # ---------------- schedule ---------------- #
    def register_schedule(self):
        T = self.num_timesteps

        if self.mt_type == "linear":
            m_min, m_max = 0.001, 0.999
            m_t = np.linspace(m_min, m_max, T)
        elif self.mt_type == "sin":
            m_t = 1.0075 ** np.linspace(0, T, T)
            m_t = m_t / m_t[-1]
            m_t[-1] = 0.999
        else:
            raise NotImplementedError

        m_tminus = np.append(0.0, m_t[:-1])
        variance_t = 2.0 * (m_t - m_t ** 2) * self.max_var
        variance_tminus = np.append(0.0, variance_t[:-1])
        variance_t_tminus = variance_t - variance_tminus * ((1.0 - m_t) / (1.0 - m_tminus)) ** 2
        posterior_variance_t = variance_t_tminus * variance_tminus / variance_t

        to_torch = partial(torch.tensor, dtype=torch.float32)
        self.register_buffer('m_t', to_torch(m_t))
        self.register_buffer('m_tminus', to_torch(m_tminus))
        self.register_buffer('variance_t', to_torch(variance_t))
        self.register_buffer('variance_tminus', to_torch(variance_tminus))
        self.register_buffer('variance_t_tminus', to_torch(variance_t_tminus))
        self.register_buffer('posterior_variance_t', to_torch(posterior_variance_t))

        if self.skip_sample:
            if self.sample_type == 'linear':
                midsteps = torch.arange(
                    self.num_timesteps - 1,
                    1,
                    step=-((self.num_timesteps - 1) / (self.sample_step - 2)),
                ).long()
                self.steps = torch.cat((midsteps, torch.tensor([1, 0]).long()), dim=0)
            elif self.sample_type == 'cosine':
                steps = np.linspace(start=0, stop=self.num_timesteps, num=self.sample_step + 1)
                steps = (np.cos(steps / self.num_timesteps * np.pi) + 1.0) / 2.0 * self.num_timesteps
                self.steps = torch.from_numpy(steps)
        else:
            self.steps = torch.arange(self.num_timesteps - 1, -1, -1)

    # ---------------- utils ---------------- #
    def apply(self, weight_init):
        self.denoise_fn.apply(weight_init)
        return self

    def get_parameters(self):
        return self.denoise_fn.parameters()

    # ----- 固定混合损失权重：无退火 -----
    def _get_mix_weights(self):
        """
        Fixed-weight ablation:
        no annealing is applied.

        In this experiment, the gradient-consistency loss is always weighted by
        a constant value w_grad = 0.08 during the whole training process.

        SSIM/PSNR are used only for logging and diagnostics, not for backpropagation.
        """
        w_ssim = self.mix_max_w_ssim   # 0.0, logging only
        w_grad = self.mix_max_w_grad   # 0.08, participates in backpropagation
        alpha = 1.0                    # fixed-weight setting, no decay
        return w_ssim, w_grad, alpha

    # ---------------- forward ---------------- #
    def forward(self, x, y, context=None):
        if self.condition_key == "nocond":
            context = None
        else:
            context = y if context is None else context

        b, c, h, w, device, img_size = *x.shape, x.device, self.image_size
        assert h == img_size and w == img_size, f'height and width of image must be {img_size}'
        t = torch.randint(0, self.num_timesteps, (b,), device=device).long()
        return self.p_losses(x, y, context, t)

    def p_losses(self, x0, y, context, t, noise=None):
        """
        主干：扩散重建误差 recloss
        + 梯度一致性损失 grad_l

        当前固定权重消融设置：
            total_loss = recloss + 0.08 * L_grad

        SSIM/PSNR 仅作为日志监控指标，不参与反向传播。
        """
        # ----- base diffusion loss -----
        b, c, h, w = x0.shape
        noise = default(noise, lambda: torch.randn_like(x0))

        x_t, objective = self.q_sample(x0, y, t, noise)
        objective_recon = self.denoise_fn(x_t, timesteps=t, context=context)

        if self.loss_type == 'l1':
            recloss = (objective - objective_recon).abs().mean()
        elif self.loss_type == 'l2':
            recloss = F.mse_loss(objective, objective_recon)
        else:
            raise NotImplementedError()

        # predict clean x0
        try:
            x0_recon = self.predict_x0_from_objective(x_t, y, t, objective_recon)
        except Exception:
            x0_recon = x0

        log_dict = {
            'recloss_noise': float(recloss.detach().mean())
        }

        # ----- structure terms -----
        try:
            # 在 LBBDM 的 latent-gradient 模式下，decode() 在训练阶段返回 latent tensor；
            # 因此下面的 L_grad 实际为潜空间梯度一致性损失。
            # 对于非 latent-gradient 模式，decode() 仍可返回图像空间结果。
            can_decode = hasattr(self, "decode") and callable(getattr(self, "decode"))
            if can_decode:
                try:
                    pred_img = self.decode(x0_recon, cond=False)
                except TypeError:
                    pred_img = self.decode(x0_recon)
                with torch.no_grad():
                    try:
                        tgt_img = self.decode(x0, cond=False)
                    except TypeError:
                        tgt_img = self.decode(x0)
            else:
                pred_img = x0_recon
                with torch.no_grad():
                    tgt_img = x0

            # If decode() returns latent tensors during LBBDM training,
            # do not clamp them to [-1, 1], because latent values are not
            # guaranteed to lie in the image normalization range.
            # For pixel-space image losses, keep the original clamp.
            if not bool(getattr(self, "_use_latent_gradient_loss", False)):
                pred_img = pred_img.clamp(-1., 1.)
                tgt_img = tgt_img.clamp(-1., 1.)

            # 固定权重，无退火
            w_ssim, w_grad, alpha = self._get_mix_weights()

            # SSIM / PSNR：完全在 CPU 上，主要用于日志
            # 注意：该函数带 @torch.no_grad()，不参与反向传播
            one_minus_ssim, psnr_mean = _ssim_psnr_downsampled(
                pred_img, tgt_img, down=2, max_pairs=8
            )

            # 梯度一致性损失：参与反向传播
            if w_grad > 0.0:
                grad_l = _gradient_loss(pred_img, tgt_img)
            else:
                grad_l = torch.zeros([], device=pred_img.device, dtype=pred_img.dtype)

            # Debug: check whether latent-space L_grad really participates in backpropagation.
            # This block prints only once. Remove or comment it out before formal long training if desired.
            if not torch.is_grad_enabled():
                if not hasattr(self, "_dbg_latgrad_nograd_printed"):
                    print("[LATENT-GRAD CHECK SKIPPED]")
                    print("  torch.is_grad_enabled() = False")
                    print("  This forward is probably validation/test/sample_to_eval.")
                    self._dbg_latgrad_nograd_printed = True

            elif not hasattr(self, "_dbg_latgrad_checked"):
                is_latent_mode = bool(getattr(self, "_use_latent_gradient_loss", False))

                print("[LATENT-GRAD CHECK]")
                print("  torch.is_grad_enabled()           =", torch.is_grad_enabled())
                print("  _use_latent_gradient_loss         =", is_latent_mode)
                print("  objective_recon.requires_grad     =", objective_recon.requires_grad)
                print("  x0_recon.requires_grad            =", x0_recon.requires_grad)
                print("  pred_img.requires_grad            =", pred_img.requires_grad)
                print("  tgt_img.requires_grad             =", tgt_img.requires_grad)
                print("  grad_l.requires_grad              =", grad_l.requires_grad)
                print("  recloss.requires_grad             =", recloss.requires_grad)

                print("  x0_recon shape                    =", tuple(x0_recon.shape))
                print("  pred_img shape                    =", tuple(pred_img.shape))
                print("  tgt_img shape                     =", tuple(tgt_img.shape))
                print("  pred_img is latent-shaped         =", tuple(pred_img.shape) == tuple(x0_recon.shape))

                try:
                    g = torch.autograd.grad(
                        grad_l,
                        objective_recon,
                        retain_graph=True,
                        allow_unused=True
                    )[0]
                    if g is None:
                        print("  grad_l -> objective_recon grad    = None")
                    else:
                        print("  grad_l -> objective_recon grad norm:", float(g.abs().mean()))
                except Exception as e:
                    print("  grad_l autograd check failed:", repr(e))

                print("  w_grad                            =", float(w_grad))
                print("  grad_l value                      =", float(grad_l.detach().mean()))
                print("  w_grad * grad_l                   =", float((w_grad * grad_l).detach().mean()))

                self._dbg_latgrad_checked = True
            # 总损失：主损失 + 固定权重梯度一致性损失
            total_loss = recloss

            # 当前 w_ssim = 0.0，因此这一项不会影响 total_loss。
            # 保留该逻辑是为了代码结构兼容。
            if w_ssim > 0.0:
                total_loss = total_loss + w_ssim * torch.as_tensor(
                    one_minus_ssim, device=recloss.device, dtype=recloss.dtype
                )

            if w_grad > 0.0:
                total_loss = total_loss + w_grad * grad_l

            # 日志：混合项贡献
            term_ssim = w_ssim * float(one_minus_ssim)
            term_grad = w_grad * float(grad_l.detach().mean())
            loss_mix = float((total_loss.detach() - recloss.detach()).mean())

            if not hasattr(self, "_dbg_mixloss_printed"):
                print(
                    f"[MIXLOSS FIXED-GRAD ENABLED] "
                    f"w_ssim={self.mix_max_w_ssim} (logging only), "
                    f"w_grad={self.mix_max_w_grad}, "
                    f"down=2, max_pairs=8, no annealing"
                )
                self._dbg_mixloss_printed = True

            log_dict.update({
                'loss_ssim': float(one_minus_ssim),
                'loss_grad': float(grad_l.detach().mean()),
                'metric_psnr': float(psnr_mean),
                'recloss_total': float(total_loss.detach().mean()),
                'loss_mix': loss_mix,
                'term_ssim': term_ssim,
                'term_grad': term_grad,
                # 固定权重实验中的配置日志
                'cfg_w_ssim': float(w_ssim),
                'cfg_w_grad': float(w_grad),
                'cfg_mix_alpha': float(alpha),
            })

        except Exception as e:
            print("[MIXLOSS DISABLED due to error]", repr(e))
            total_loss = recloss
            # 兜底也写键，值置 0，TensorBoard 就一定能看到曲线
            log_dict.update({
                'recloss_total': float(total_loss.detach().mean()),
                'loss_mix': 0.0,
                'term_ssim': 0.0,
                'term_grad': 0.0,
                'cfg_w_ssim': 0.0,
                'cfg_w_grad': 0.0,
                'cfg_mix_alpha': 0.0,
            })

        return total_loss, log_dict

    # ---------------- diffusion math ---------------- #
    def q_sample(self, x0, y, t, noise=None):
        noise = default(noise, lambda: torch.randn_like(x0))
        m_t = extract(self.m_t, t, x0.shape)
        var_t = extract(self.variance_t, t, x0.shape)
        sigma_t = torch.sqrt(var_t)

        if self.objective == 'grad':
            objective = m_t * (y - x0) + sigma_t * noise
        elif self.objective == 'noise':
            objective = noise
        elif self.objective == 'ysubx':
            objective = y - x0
        else:
            raise NotImplementedError()

        return (
            (1.0 - m_t) * x0 + m_t * y + sigma_t * noise,
            objective,
        )

    def predict_x0_from_objective(self, x_t, y, t, objective_recon):
        if self.objective == 'grad':
            x0_recon = x_t - objective_recon
        elif self.objective == 'noise':
            m_t = extract(self.m_t, t, x_t.shape)
            var_t = extract(self.variance_t, t, x_t.shape)
            sigma_t = torch.sqrt(var_t)
            x0_recon = (x_t - m_t * y - sigma_t * objective_recon) / (1.0 - m_t)
        elif self.objective == 'ysubx':
            x0_recon = y - objective_recon
        else:
            raise NotImplementedError
        return x0_recon

    @torch.no_grad()
    def q_sample_loop(self, x0, y):
        imgs = [x0]
        for i in tqdm(range(self.num_timesteps), desc='q sampling loop', total=self.num_timesteps):
            t = torch.full((y.shape[0],), i, device=x0.device, dtype=torch.long)
            img, _ = self.q_sample(x0, y, t)
            imgs.append(img)
        return imgs

    @torch.no_grad()
    def p_sample(self, x_t, y, context, i, clip_denoised=False):
        if self.steps[i] == 0:
            t = torch.full((x_t.shape[0],), self.steps[i], device=x_t.device, dtype=torch.long)
            objective_recon = self.denoise_fn(x_t, timesteps=t, context=context)
            x0_recon = self.predict_x0_from_objective(x_t, y, t, objective_recon=objective_recon)
            if clip_denoised:
                x0_recon.clamp_(-1., 1.)
            return x0_recon, x0_recon
        else:
            t = torch.full((x_t.shape[0],), self.steps[i], device=x_t.device, dtype=torch.long)
            n_t = torch.full((x_t.shape[0],), self.steps[i + 1], device=x_t.device, dtype=torch.long)

            objective_recon = self.denoise_fn(x_t, timesteps=t, context=context)
            x0_recon = self.predict_x0_from_objective(x_t, y, t, objective_recon=objective_recon)
            if clip_denoised:
                x0_recon.clamp_(-1., 1.)

            m_t = extract(self.m_t, t, x_t.shape)
            m_nt = extract(self.m_t, n_t, x_t.shape)
            var_t = extract(self.variance_t, t, x_t.shape)
            var_nt = extract(self.variance_t, n_t, x_t.shape)
            sigma2_t = (var_t - var_nt * (1. - m_t) ** 2 / (1. - m_nt) ** 2) * var_nt / var_t
            sigma_t = torch.sqrt(sigma2_t) * self.eta

            noise = torch.randn_like(x_t)
            x_tminus_mean = (
                (1. - m_nt) * x0_recon
                + m_nt * y
                + torch.sqrt((var_nt - sigma2_t) / var_t)
                * (x_t - (1. - m_t) * x0_recon - m_t * y)
            )

            return x_tminus_mean + sigma_t * noise, x0_recon

    @torch.no_grad()
    def p_sample_loop(self, y, context=None, clip_denoised=True, sample_mid_step=False):
        if self.condition_key == "nocond":
            context = None
        else:
            context = y if context is None else context

        if sample_mid_step:
            imgs, one_step_imgs = [y], []
            for i in tqdm(range(len(self.steps)), desc='sampling loop time step', total=len(self.steps)):
                img, x0_recon = self.p_sample(
                    x_t=imgs[-1],
                    y=y,
                    context=context,
                    i=i,
                    clip_denoised=clip_denoised,
                )
                imgs.append(img)
                one_step_imgs.append(x0_recon)
            return imgs, one_step_imgs
        else:
            img = y
            for i in tqdm(range(len(self.steps)), desc='sampling loop time step', total=len(self.steps)):
                img, _ = self.p_sample(
                    x_t=img,
                    y=y,
                    context=context,
                    i=i,
                    clip_denoised=clip_denoised,
                )
            return img

    @torch.no_grad()
    def sample(self, y, context=None, clip_denoised=True, sample_mid_step=False):
        return self.p_sample_loop(y, context, clip_denoised, sample_mid_step)


# ---------------- losses & metrics helpers ---------------- #
def _gradient_loss(pred, target, mask=None):
    """
    Gradient-consistency loss.

    In pixel-space mode, pred/target are normalized images.
    In LBBDM latent-gradient mode, pred/target are latent tensors
    and should not be forcibly clamped to [-1, 1].
    """
    gx_p = pred[..., :, 1:] - pred[..., :, :-1]
    gy_p = pred[..., 1:, :] - pred[..., :-1, :]
    gx_t = target[..., :, 1:] - target[..., :, :-1]
    gy_t = target[..., 1:, :] - target[..., :-1, :]

    if mask is None:
        return (gx_p - gx_t).abs().mean() + (gy_p - gy_t).abs().mean()
    else:
        mask_x = mask[..., :, 1:] * mask[..., :, :-1]
        mask_y = mask[..., 1:, :] * mask[..., :-1, :]
        loss_x = ((gx_p - gx_t).abs() * mask_x).sum() / (mask_x.sum() + 1e-8)
        loss_y = ((gy_p - gy_t).abs() * mask_y).sum() / (mask_y.sum() + 1e-8)
        return loss_x + loss_y


@torch.no_grad()
def _ssim_psnr_downsampled(pred_img, tgt_img, down=2, max_pairs=8):
    """
    完全在 CPU 上计算的 SSIM/PSNR，日志用。
    不参与反向传播。
    """
    # 搬到 CPU，避免占用 GPU 显存
    pred_img = pred_img.detach().float().cpu()
    tgt_img = tgt_img.detach().float().cpu()

    B = pred_img.size(0)
    m = min(B, max_pairs)

    # 在 CPU 上插值
    pred_small = F.interpolate(
        pred_img[:m],
        scale_factor=1 / down,
        mode='bilinear',
        align_corners=False
    )
    tgt_small = F.interpolate(
        tgt_img[:m],
        scale_factor=1 / down,
        mode='bilinear',
        align_corners=False
    )

    p = ((pred_small.clamp(-1, 1) + 1) / 2 * 255).permute(0, 2, 3, 1).numpy().astype('uint8')
    t = ((tgt_small.clamp(-1, 1) + 1) / 2 * 255).permute(0, 2, 3, 1).numpy().astype('uint8')

    ssim_vals, psnr_vals = [], []
    for i in range(m):
        ssim_vals.append(float(calculate_ssim(p[i], t[i])))
        psnr_vals.append(float(calculate_psnr(p[i], t[i])))

    import numpy as _np
    ssim_mean = float(_np.mean(ssim_vals)) if ssim_vals else 0.0
    psnr_mean = float(_np.mean(psnr_vals)) if psnr_vals else 0.0

    return (1.0 - ssim_mean), psnr_mean