import os
from collections import defaultdict

import torch
import torch.optim.lr_scheduler
from torch.utils.data import DataLoader

from PIL import Image
from Register import Registers
from model.BrownianBridge.BrownianBridgeModel import BrownianBridgeModel
from model.BrownianBridge.LatentBrownianBridgeModel import LatentBrownianBridgeModel
from runners.DiffusionBasedModelRunners.DiffusionBaseRunner import DiffusionBaseRunner
from runners.utils import weights_init, get_optimizer, get_dataset, make_dir, get_image_grid, save_single_image
from tqdm.autonotebook import tqdm
from torchsummary import summary


@Registers.runners.register_with_name('BBDMRunner')
class BBDMRunner(DiffusionBaseRunner):
    def __init__(self, config):
        super().__init__(config)
        # ——本 epoch 的在线累计器（均值用）——
        self._epoch_meters = {
            'train': defaultdict(float),
            'val': defaultdict(float),
            'test': defaultdict(float),
        }
        self._epoch_counts = {'train': 0, 'val': 0, 'test': 0}
        self._last_epoch = -1

        # 仅记录到板子：谁是当前最优 PSNR（不影响保存策略）
        self._best = {'psnr': float('-inf'), 'epoch': -1}

    # ---------- helpers for meters ----------
    def _reset_epoch_stats(self, stages=('train', 'val', 'test')):
        for s in stages:
            self._epoch_meters[s].clear()
            self._epoch_counts[s] = 0

    def _accumulate_stats(self, stage, info: dict):
        if not isinstance(info, dict):
            return
        # 这些键都会汇总均值
        keys = (
            'metric_psnr', 'loss_ssim', 'loss_grad', 'recloss_total',
            'recloss_noise', 'loss_mix', 'loss_mix_ratio',
            'term_ssim', 'term_grad',
            'cfg_w_grad', 'cfg_w_ssim', 'cfg_ssim_down', 'cfg_ssim_pairs'
        )
        for k in keys:
            if k in info:
                try:
                    v = float(info[k].item()) if hasattr(info[k], 'item') else float(info[k])
                    self._epoch_meters[stage][k] += v
                except Exception:
                    pass
        self._epoch_counts[stage] += 1

    # ---------- core hooks ----------
    def initialize_model(self, config):
        if config.model.model_type == "BBDM":
            bbdmnet = BrownianBridgeModel(config.model).to(config.training.device[0])
        elif config.model.model_type == "LBBDM":
            bbdmnet = LatentBrownianBridgeModel(config.model).to(config.training.device[0])
        else:
            raise NotImplementedError
        bbdmnet.apply(weights_init)

        self.print_model_summary(bbdmnet)

        return bbdmnet

    def load_model_from_checkpoint(self):
        states = None
        if self.config.model.only_load_latent_mean_std:
            if self.config.model.__contains__('model_load_path') and self.config.model.model_load_path is not None:
                states = torch.load(self.config.model.model_load_path, map_location='cpu')
        else:
            states = super().load_model_from_checkpoint()

        if self.config.model.normalize_latent:
            if states is not None:
                self.net.ori_latent_mean = states['ori_latent_mean'].to(self.config.training.device[0])
                self.net.ori_latent_std = states['ori_latent_std'].to(self.config.training.device[0])
                self.net.cond_latent_mean = states['cond_latent_mean'].to(self.config.training.device[0])
                self.net.cond_latent_std = states['cond_latent_std'].to(self.config.training.device[0])
            else:
                if self.config.args.train:
                    self.get_latent_mean_std()

    def print_model_summary(self, net):
        def get_parameter_number(model):
            total_num = sum(p.numel() for p in model.parameters())
            trainable_num = sum(p.numel() for p in model.parameters() if p.requires_grad)
            return total_num, trainable_num

        total_num, trainable_num = get_parameter_number(net)
        print("Total Number of parameter: %.2fM" % (total_num / 1e6))
        print("Trainable Number of parameter: %.2fM" % (trainable_num / 1e6))

    def initialize_optimizer_scheduler(self, net, config):
        optimizer = get_optimizer(config.model.BB.optimizer, net.get_parameters())
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer=optimizer,
            mode='min',
            verbose=True,
            threshold_mode='rel',
            **vars(config.model.BB.lr_scheduler)
        )
        return [optimizer], [scheduler]

    @torch.no_grad()
    def get_checkpoint_states(self, stage='epoch_end'):
        # ——在 epoch 末尾，做一次“验证均值”汇总 + 自适应调参 + 日志落板——
        # 先拿到父类的 states（也保持你的保存流程）
        model_states, optimizer_scheduler_states = super().get_checkpoint_states()

        # 如果本 epoch 有做验证，就计算均值
        val_n = self._epoch_counts.get('val', 0)
        if val_n > 0:
            means = {k: v / val_n for k, v in self._epoch_meters['val'].items()}

            # 1) 写到 TensorBoard（epoch 粒度）
            epoch_idx = getattr(self, 'epoch', None)
            epoch_tag = int(epoch_idx) if epoch_idx is not None else int(self.global_epoch)

            def _add_scalar_safe(tag, key):
                if key in means:
                    try:
                        self.writer.add_scalar(tag, float(means[key]), epoch_tag)
                    except Exception:
                        pass

            _add_scalar_safe('val/metric_psnr_mean', 'metric_psnr')
            _add_scalar_safe('val/loss_ssim_mean', 'loss_ssim')          # 注意：这是 1-SSIM
            _add_scalar_safe('val/loss_grad_mean', 'loss_grad')
            _add_scalar_safe('val/recloss_total_mean', 'recloss_total')
            _add_scalar_safe('val/recloss_noise_mean', 'recloss_noise')
            _add_scalar_safe('val/loss_mix_mean', 'loss_mix')
            _add_scalar_safe('val/loss_mix_ratio_mean', 'loss_mix_ratio')

            # 当前混合损失的配置也落板（来自模型实时权重）
            if hasattr(self.net, 'w_grad'):
                try:
                    self.writer.add_scalar('hp/w_grad', float(self.net.w_grad), epoch_tag)
                    self.writer.add_scalar('hp/w_ssim', float(self.net.w_ssim), epoch_tag)
                    self.writer.add_scalar('hp/ssim_down', float(self.net.ssim_down), epoch_tag)
                    self.writer.add_scalar('hp/ssim_pairs', float(self.net.ssim_pairs), epoch_tag)
                except Exception:
                    pass

            # 2) 触发一次轻量自适应（只需要均值）
            if hasattr(self.net, 'adapt_weights'):
                self.net.adapt_weights(
                    val_psnr=means.get('metric_psnr', None),
                    val_one_minus_ssim=means.get('loss_ssim', None),
                    val_loss_grad=means.get('loss_grad', None),
                    val_loss_mix_ratio=means.get('loss_mix_ratio', None),
                )

            # 3) 仅用于可视化的“最佳 PSNR 追踪”
            cur_psnr = means.get('metric_psnr', None)
            if cur_psnr is not None and cur_psnr > self._best['psnr']:
                self._best['psnr'] = float(cur_psnr)
                self._best['epoch'] = epoch_tag
                try:
                    self.writer.add_scalar('top/best_psnr', self._best['psnr'], epoch_tag)
                    self.writer.add_scalar('top/best_epoch', self._best['epoch'], epoch_tag)
                except Exception:
                    pass

            # 用完就清空 val 统计，避免跨 epoch 污染
            self._epoch_meters['val'].clear()
            self._epoch_counts['val'] = 0

        return model_states, optimizer_scheduler_states

    def get_latent_mean_std(self):
        train_dataset, val_dataset, test_dataset = get_dataset(self.config.data)
        train_loader = DataLoader(train_dataset,
                                  batch_size=self.config.data.train.batch_size,
                                  shuffle=True,
                                  num_workers=8,
                                  drop_last=True)

        total_ori_mean = None
        total_ori_var = None
        total_cond_mean = None
        total_cond_var = None
        max_batch_num = 30000 // self.config.data.train.batch_size

        def calc_mean(batch, total_ori_mean=None, total_cond_mean=None):
            (x, x_name), (x_cond, x_cond_name) = batch
            x = x.to(self.config.training.device[0])
            x_cond = x_cond.to(self.config.training.device[0])

            x_latent = self.net.encode(x, cond=False, normalize=False)
            x_cond_latent = self.net.encode(x_cond, cond=True, normalize=False)
            x_mean = x_latent.mean(axis=[0, 2, 3], keepdim=True)
            total_ori_mean = x_mean if total_ori_mean is None else x_mean + total_ori_mean

            x_cond_mean = x_cond_latent.mean(axis=[0, 2, 3], keepdim=True)
            total_cond_mean = x_cond_mean if total_cond_mean is None else x_cond_mean + total_cond_mean
            return total_ori_mean, total_cond_mean

        def calc_var(batch, ori_latent_mean=None, cond_latent_mean=None, total_ori_var=None, total_cond_var=None):
            (x, x_name), (x_cond, x_cond_name) = batch
            x = x.to(self.config.training.device[0])
            x_cond = x_cond.to(self.config.training.device[0])

            x_latent = self.net.encode(x, cond=False, normalize=False)
            x_cond_latent = self.net.encode(x_cond, cond=True, normalize=False)
            x_var = ((x_latent - ori_latent_mean) ** 2).mean(axis=[0, 2, 3], keepdim=True)
            total_ori_var = x_var if total_ori_var is None else x_var + total_ori_var

            x_cond_var = ((x_cond_latent - cond_latent_mean) ** 2).mean(axis=[0, 2, 3], keepdim=True)
            total_cond_var = x_cond_var if total_cond_var is None else x_cond_var + total_cond_var
            return total_ori_var, total_cond_var

        print(f"start calculating latent mean")
        batch_count = 0
        for train_batch in tqdm(train_loader, total=len(train_loader), smoothing=0.01):
            batch_count += 1
            total_ori_mean, total_cond_mean = calc_mean(train_batch, total_ori_mean, total_cond_mean)

        ori_latent_mean = total_ori_mean / batch_count
        self.net.ori_latent_mean = ori_latent_mean

        cond_latent_mean = total_cond_mean / batch_count
        self.net.cond_latent_mean = cond_latent_mean

        print(f"start calculating latent std")
        batch_count = 0
        for train_batch in tqdm(train_loader, total=len(train_loader), smoothing=0.01):
            batch_count += 1
            total_ori_var, total_cond_var = calc_var(train_batch,
                                                     ori_latent_mean=ori_latent_mean,
                                                     cond_latent_mean=cond_latent_mean,
                                                     total_ori_var=total_ori_var,
                                                     total_cond_var=total_cond_var)

        ori_latent_var = total_ori_var / batch_count
        cond_latent_var = total_cond_var / batch_count

        self.net.ori_latent_std = torch.sqrt(ori_latent_var)
        self.net.cond_latent_std = torch.sqrt(cond_latent_var)
        print(self.net.ori_latent_mean)
        print(self.net.ori_latent_std)
        print(self.net.cond_latent_mean)
        print(self.net.cond_latent_std)

    def loss_fn(self, net, batch, epoch, step, opt_idx=0, stage='train', write=True):
        # ——epoch 切换时重置统计——
        if int(epoch) != self._last_epoch:
            self._reset_epoch_stats(('train', 'val'))  # 每个新 epoch 重置 train/val 的统计
            self._last_epoch = int(epoch)

        (x, x_name), (x_cond, x_cond_name) = batch
        x = x.to(self.config.training.device[0])
        x_cond = x_cond.to(self.config.training.device[0])

        loss, additional_info = net(x, x_cond)

        # ——累计统计（每个 batch 都记，便于 epoch 均值）——
        stg = str(stage).lower()
        if stg.startswith('train'):
            self._accumulate_stats('train', additional_info)
        elif stg.startswith('val'):
            self._accumulate_stats('val', additional_info)
        elif stg.startswith('test'):
            self._accumulate_stats('test', additional_info)

        # ——标量写板（保持你原逻辑）——
        step_tag = int(step)
        if write:
            self.writer.add_scalar(f'loss/{stage}', loss, step_tag)

        is_train = stg.startswith('train')
        write_struct = (is_train and (step_tag % 50 == 0)) or ((not is_train) and write)

        if write_struct and isinstance(additional_info, dict):
            # 常规结构项
            for k in ('loss_ssim', 'loss_grad', 'metric_psnr', 'recloss_total'):
                if k in additional_info:
                    try:
                        v = float(additional_info[k].item()) if hasattr(additional_info[k], "item") else float(additional_info[k])
                        self.writer.add_scalar(f'{k}/{stage}', v, step_tag)
                    except Exception:
                        pass

            # 原有的 noise / xy
            if 'recloss_noise' in additional_info:
                try:
                    rn = float(additional_info['recloss_noise'])
                    self.writer.add_scalar(f'recloss_noise/{stage}', rn, step_tag)
                except Exception:
                    pass
            if 'recloss_xy' in additional_info:
                try:
                    rx = float(additional_info['recloss_xy'])
                    self.writer.add_scalar(f'recloss_xy/{stage}', rx, step_tag)
                except Exception:
                    pass

            # 新增：混合贡献、占比、以及当前权重/配置
            if ('recloss_total' in additional_info) and ('recloss_noise' in additional_info):
                try:
                    rt = float(additional_info['recloss_total'])
                    rn = float(additional_info['recloss_noise'])
                    loss_mix = rt - rn
                    self.writer.add_scalar(f'loss_mix/{stage}', loss_mix, step_tag)
                except Exception:
                    pass

            for cfg_k in ('loss_mix_ratio', 'term_ssim', 'term_grad',
                          'cfg_w_grad', 'cfg_w_ssim', 'cfg_ssim_down', 'cfg_ssim_pairs'):
                if cfg_k in additional_info:
                    try:
                        cv = float(additional_info[cfg_k])
                        self.writer.add_scalar(f'{cfg_k}/{stage}', cv, step_tag)
                    except Exception:
                        pass

        return loss

    @torch.no_grad()
    def sample(self, net, batch, sample_path, stage='train'):
        sample_path = make_dir(os.path.join(sample_path, f'{stage}_sample'))
        reverse_sample_path = make_dir(os.path.join(sample_path, 'reverse_sample'))
        reverse_one_step_path = make_dir(os.path.join(sample_path, 'reverse_one_step_samples'))

        (x, x_name), (x_cond, x_cond_name) = batch

        batch_size = x.shape[0] if x.shape[0] < 4 else 4

        x = x[0:batch_size].to(self.config.training.device[0])
        x_cond = x_cond[0:batch_size].to(self.config.training.device[0])

        grid_size = 4

        sample = net.sample(x_cond, clip_denoised=self.config.testing.clip_denoised).to('cpu')
        image_grid = get_image_grid(sample, grid_size, to_normal=self.config.data.dataset_config.to_normal)
        im = Image.fromarray(image_grid)
        im.save(os.path.join(sample_path, 'skip_sample.png'))
        if stage != 'test':
            self.writer.add_image(f'{stage}_skip_sample', image_grid, self.global_step, dataformats='HWC')

        image_grid = get_image_grid(x_cond.to('cpu'), grid_size, to_normal=self.config.data.dataset_config.to_normal)
        im = Image.fromarray(image_grid)
        im.save(os.path.join(sample_path, 'condition.png'))
        if stage != 'test':
            self.writer.add_image(f'{stage}_condition', image_grid, self.global_step, dataformats='HWC')

        image_grid = get_image_grid(x.to('cpu'), grid_size, to_normal=self.config.data.dataset_config.to_normal)
        im = Image.fromarray(image_grid)
        im.save(os.path.join(sample_path, 'ground_truth.png'))
        if stage != 'test':
            self.writer.add_image(f'{stage}_ground_truth', image_grid, self.global_step, dataformats='HWC')

    @torch.no_grad()
    def sample_to_eval(self, net, test_loader, sample_path):
        condition_path = make_dir(os.path.join(sample_path, f'condition'))
        gt_path = make_dir(os.path.join(sample_path, 'ground_truth'))
        result_path = make_dir(os.path.join(sample_path, str(self.config.model.BB.params.sample_step)))

        pbar = tqdm(test_loader, total=len(test_loader), smoothing=0.01)
        batch_size = self.config.data.test.batch_size
        to_normal = self.config.data.dataset_config.to_normal
        sample_num = self.config.testing.sample_num
        for test_batch in pbar:
            (x, x_name), (x_cond, x_cond_name) = test_batch
            x = x.to(self.config.training.device[0])
            x_cond = x_cond.to(self.config.training.device[0])

            for j in range(sample_num):
                sample = net.sample(x_cond, clip_denoised=False)
                for i in range(batch_size):
                    condition = x_cond[i].detach().clone()
                    gt = x[i]
                    result = sample[i]
                    if j == 0:
                        save_single_image(condition, condition_path, f'{x_cond_name[i]}.png', to_normal=to_normal)
                        save_single_image(gt, gt_path, f'{x_name[i]}.png', to_normal=to_normal)
                    if sample_num > 1:
                        result_path_i = make_dir(os.path.join(result_path, x_name[i]))
                        save_single_image(result, result_path_i, f'output_{j}.png', to_normal=to_normal)
                    else:
                        save_single_image(result, result_path, f'{x_name[i]}.png', to_normal=to_normal)
